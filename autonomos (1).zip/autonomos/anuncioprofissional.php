<?php
require 'conexao.php';

if (isset($_GET['idAnuncio'])) {
    $idAnuncio = $_GET['idAnuncio'];
    $sql = "SELECT * FROM anuncio WHERE IDANUNCIO = :idAnuncio";
    $stmt = $conexao->prepare($sql);
    $stmt->bindParam(':idAnuncio', $idAnuncio);
    $stmt->execute();
    $anuncio = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($anuncio) {
        $nome = htmlspecialchars($anuncio['NOME']);
        $redeSocial = htmlspecialchars($anuncio['REDESOCIAL']);
        $telefone = htmlspecialchars($anuncio['TELEFONE']);
        $email = htmlspecialchars($anuncio['EMAIL']);
        $trabalho = htmlspecialchars($anuncio['TRABALHO']);
        $especializacao = htmlspecialchars($anuncio['ESPECIALIZACAO']);
        $local = htmlspecialchars($anuncio['LOCAL']);
        $descricao = htmlspecialchars($anuncio['DESCRICAO']);
        $enderecoAnuncio = htmlspecialchars($anuncio['ENDERECOANUNCIO']);
        $horarios = htmlspecialchars($anuncio['HORARIOS']);
        $imagem = htmlspecialchars($anuncio['IMAGEM']);
        ?>

        <!DOCTYPE html>
        <html lang="pt-br">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title><?= $nome ?></title>
            <link rel="stylesheet" href="./assets/style.css">
            <link rel="stylesheet" href="./assets/styleanuncioprofissional.css">
        </head>
        <body>
            <nav class="nav">
                <a href="index.php"><img class="nav-logo" src="./assets/img/title.svg"></a>
                <ul class="nav-items">
                    <li class="nav-item" id="nav-Nossos-servicos"><a href="home.php">Nossos serviços</a></li>
                    <li class="nav-item" id="nav-Criar-anuncio"><a href="criaranuncio.php">Criar um anúncio</a></li>
                    <li class="nav-item"><a href="perfil.php">Perfil</a></li>
                </ul>
            </nav>
            <main>
                <div class="main-container">
                    <div class="first-infos">
                        <h1 id="nome"><?= $nome ?></h1>
                        <p id="redeSocial">Contato: <?= $redeSocial ?></p>
                        <p id="telefone">Telefone: <?= $telefone ?></p>
                        <p id="email"><?= $email ?></p>
                        <p id="trabalho">Área de atuação: <?= $trabalho ?></p>
                        <p id="especializacao">Especialização: <?= $especializacao ?></p>
                        <p id="local">Local: <?= $local ?></p>
                        <p id="enderecoAnuncio"><?= $enderecoAnuncio ?></p>
                        <p id="horarios">Horários: <?= $horarios ?></p>
                    </div>
                    <div class="second-infos">
                        <img src="<?= $imagem ?>" alt="Imagem do anúncio" class="big-image">
                        <p class="descricao"><?= $descricao ?></p>
                    </div>
                </div>
            </main>
        </body>
        </html>

        <?php
    } else {
        header("Location: erro.php");
        exit();
    }
} else {
    header("Location: erro.php");
    exit();
}
?>