<?php
include 'conexao.php';
session_start();

// Verifica se os dados foram enviados via POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtém os dados do formulário
    $login = $_POST['login'];
    $senha = $_POST['senha']; // Criptografa a senha
    $email = $_POST['email'];
    $cpf = $_POST['cpf'];

    // Prepara a instrução SQL para inserção
    $sql = "INSERT INTO usuario (login, senha, email, cpf) VALUES (:login, :senha, :email, :cpf)";
    $stmt = $conexao->prepare($sql);
    $stmt->bindParam(':login', $login);
    $stmt->bindParam(':senha', $senha);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':cpf', $cpf);

    // Executa a instrução SQL
    if ($stmt->execute()) {
        $msg = "Cadastro realizado com sucesso!";
    } else {
        $msg = "Erro ao cadastrar o usuário.";
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro</title>
    <link rel="stylesheet" href="./assets/styleCadastro.css">
</head>
<body>
    <div class="main-login">
        <div class="left-login"></div>
        <div class="right-login">
            <div class="card-login">
                <h1>CADASTRO</h1>
                <form action="processa_cadastro.php" method="post">
                    <div class="textfield">
                        <label for="login">Usuário</label>
                        <input type="text" name="login" placeholder="Insira o seu usuário." maxlength="255"required>
                    </div>
                    <div class="textfield">
                        <label for="senha">Senha</label>
                        <input type="password" name="senha" placeholder="Insira a sua senha." maxlength="20" required>
                    </div>
                    <div class="textfield">
                        <label for="email">Email</label>
                        <input type="email" name="email" placeholder="Insira o seu endereço de E-mail." maxlength="255" required>
                    </div>
                    <div class="textfield">
                        <label for="cpf">CPF</label>
                        <input type="text" name="cpf" placeholder="Insira o seu CPF." maxlength="14"required>
                    </div>
                    <button type="submit" class="btn-login">Cadastrar</button>
                </form>
                <p class="redirecionar-login">Já tem cadastro? <a href="login.php">Login</a></p>
            </div>
        </div>
        <img class="login-image" src="./assets/img/imagem-efeito-gradiente.svg">
    </div>
</body>
</html>
