<?php
class Anuncio {
    private $idAnuncio;
    private $idUsuario;
    private $idAvaliacao;
    private $redeSocial;
    private $telefone;
    private $email;
    private $trabalho;
    private $especializacao;
    private $local;
    private $descricao;
    private $horarios;
    private $imagem;
    private $nome;

    // Getters and Setters
    public function getIdAnuncio() {
        return $this->idAnuncio;
    }

    public function setIdAnuncio($idAnuncio) {
        $this->idAnuncio = $idAnuncio;
    }

    public function getIdUsuario() {
        return $this->idUsuario;
    }

    public function setIdUsuario($idUsuario) {
        $this->idUsuario = $idUsuario;
    }

    public function getIdAvaliacao() {
        return $this->idAvaliacao;
    }

    public function setIdAvaliacao($idAvaliacao) {
        $this->idAvaliacao = $idAvaliacao;
    }

    public function getRedeSocial() {
        return $this->redeSocial;
    }

    public function setRedeSocial($redeSocial) {
        $this->redeSocial = $redeSocial;
    }

    public function getTelefone() {
        return $this->telefone;
    }

    public function setTelefone($telefone) {
        $this->telefone = $telefone;
    }

    public function getEmail() {
        return $this->email;
    }

    public function setEmail($email) {
        $this->email = $email;
    }

    public function getTrabalho() {
        return $this->trabalho;
    }

    public function setTrabalho($trabalho) {
        $this->trabalho = $trabalho;
    }

    public function getEspecializacao() {
        return $this->especializacao;
    }

    public function setEspecializacao($especializacao) {
        $this->especializacao = $especializacao;
    }

    public function getLocal() {
        return $this->local;
    }

    public function setLocal($local) {
        $this->local = $local;
    }

    public function getDescricao() {
        return $this->descricao;
    }

    public function setDescricao($descricao) {
        $this->descricao = $descricao;
    }

    public function getHorarios() {
        return $this->horarios;
    }

    public function setHorarios($horarios) {
        $this->horarios = $horarios;
    }

    public function getImagem() {
        return $this->imagem;
    }

    public function setImagem($imagem) {
        $this->imagem = $imagem;
    }

    public function getNome() {
        return $this->nome;
    }

    public function setNome($nome) {
        $this->nome = $nome;
    }

    // CRUD Methods
    public function create($pdo) {
        $sql = "INSERT INTO anuncio (IDUSUARIO, IDAVALIACAO, NOME, REDESOCIAL, TELEFONE, EMAIL, TRABALHO, ESPECIALIZACAO, LOCAL, DESCRICAO, HORARIOS, IMAGEM) 
                VALUES (:idUsuario, :idAvaliacao, :nome, :redeSocial, :telefone, :email, :trabalho, :especializacao, :local, :descricao, :horarios, :imagem)";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':idUsuario', $this->idUsuario);
        $stmt->bindParam(':idAvaliacao', $this->idAvaliacao);
        $stmt->bindParam(':nome', $this->nome);
        $stmt->bindParam(':redeSocial', $this->redeSocial);
        $stmt->bindParam(':telefone', $this->telefone);
        $stmt->bindParam(':email', $this->email);
        $stmt->bindParam(':trabalho', $this->trabalho);
        $stmt->bindParam(':especializacao', $this->especializacao);
        $stmt->bindParam(':local', $this->local);
        $stmt->bindParam(':descricao', $this->descricao);
        $stmt->bindParam(':horarios', $this->horarios);
        $stmt->bindParam(':imagem', $this->imagem);
        return $stmt->execute();
    }

    public function read($pdo, $idAnuncio) {
        $sql = "SELECT * FROM anuncio WHERE IDANUNCIO = :idAnuncio";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':idAnuncio', $idAnuncio);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($result) {
            $this->idAnuncio = $result['IDANUNCIO'];
            $this->idUsuario = $result['IDUSUARIO'];
            $this->idAvaliacao = $result['IDAVALIACAO'];
            $this->redeSocial = $result['REDESOCIAL'];
            $this->telefone = $result['TELEFONE'];
            $this->email = $result['EMAIL'];
            $this->trabalho = $result['TRABALHO'];
            $this->especializacao = $result['ESPECIALIZACAO'];
            $this->local = $result['LOCAL'];
            $this->descricao = $result['DESCRICAO'];
            $this->horarios = $result['HORARIOS'];
            $this->imagem = $result['IMAGEM'];
            return true;
        }
        return false;
    }

    public function readAllByUserId($pdo, $idUsuario) {
        $sql = "SELECT * FROM anuncio WHERE IDUSUARIO = :idUsuario";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':idUsuario', $idUsuario);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function update($pdo) {
        $sql = "UPDATE anuncio SET IDUSUARIO = :idUsuario, IDAVALIACAO = :idAvaliacao, REDESOCIAL = :redeSocial, TELEFONE = :telefone, EMAIL = :email, TRABALHO = :trabalho, ESPECIALIZACAO = :especializacao, LOCAL = :local, DESCRICAO = :descricao, HORARIOS = :horarios, IMAGEM = :imagem WHERE IDANUNCIO = :idAnuncio";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':idAnuncio', $this->idAnuncio);
        $stmt->bindParam(':idUsuario', $this->idUsuario);
        $stmt->bindParam(':idAvaliacao', $this->idAvaliacao);
        $stmt->bindParam(':redeSocial', $this->redeSocial);
        $stmt->bindParam(':telefone', $this->telefone);
        $stmt->bindParam(':email', $this->email);
        $stmt->bindParam(':trabalho', $this->trabalho);
        $stmt->bindParam(':especializacao', $this->especializacao);
        $stmt->bindParam(':local', $this->local);
        $stmt->bindParam(':descricao', $this->descricao);
        $stmt->bindParam(':horarios', $this->horarios);
        $stmt->bindParam(':imagem', $this->imagem);
        return $stmt->execute();
    }

    public function delete($pdo, $idAnuncio) {
        $sql = "DELETE FROM anuncio WHERE IDANUNCIO = :idAnuncio";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':idAnuncio', $idAnuncio);
        return $stmt->execute();
    }
}
?>
