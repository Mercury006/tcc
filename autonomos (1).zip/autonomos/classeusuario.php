<?php
class Usuario {
    private $idUsuario;
    private $login;
    private $senha;
    private $email;
    private $cpf;

    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    // Getters and Setters
    public function getIdUsuario() {
        return $this->idUsuario;
    }

    public function getLogin() {
        return $this->login;
    }

    public function setLogin($login) {
        $this->login = $login;
    }

    public function getSenha() {
        return $this->senha;
    }

    public function setSenha($senha) {
        $this->senha = $senha;
    }

    public function getEmail() {
        return $this->email;
    }

    public function setEmail($email) {
        $this->email = $email;
    }

    public function getCpf() {
        return $this->cpf;
    }

    public function setCpf($cpf) {
        $this->cpf = $cpf;
    }

    // CRUD Operations
    public function create() {
        try {
            $stmt = $this->pdo->prepare("INSERT INTO usuario (LOGIN, SENHA, EMAIL, CPF) VALUES (:login, :senha, :email, :cpf)");
            
            // Bind dos valores para os placeholders
            $stmt->bindParam(':login', $this->login);
            $stmt->bindParam(':senha', $this->senha);
            $stmt->bindParam(':email', $this->email);
            $stmt->bindParam(':cpf', $this->cpf);
            
            // Executa a instrução SQL
            return $stmt->execute();
        } catch (PDOException $e) {
            // Em caso de erro na execução da instrução SQL, lança uma exceção 
            throw new PDOException($e->getMessage());
        }
    }

    public function read($login, $senha) {
        try {
            $stmt = $this->pdo->prepare("SELECT * FROM usuario WHERE LOGIN = :login AND SENHA = :senha");
            $executionResult = $stmt->execute([':login' => $login, ':senha' => $senha]);
    
            if ($executionResult) {
                $row = $stmt->fetch(PDO::FETCH_ASSOC);
                if ($row) {
                    $this->idUsuario = $row['IDUSUARIO'];
                    $this->login = $row['LOGIN'];
                    $this->senha = $row['SENHA'];
                    $this->email = $row['EMAIL'];
                    $this->cpf = $row['CPF'];
                    return true;
                }
            }
        } catch (PDOException $e) {
            // Log error message or handle it as needed
            error_log("Database error: " . $e->getMessage());
        }
        return false;
    }

    public function readById($idUsuario) {
        try {
            $stmt = $this->pdo->prepare("SELECT * FROM usuario WHERE IDUSUARIO = :idUsuario");
            $stmt->bindParam(':idUsuario', $idUsuario, PDO::PARAM_INT);
            $stmt->execute();
    
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            if ($row) {
                $this->idUsuario = $row['IDUSUARIO'];
                $this->login = $row['LOGIN'];
                $this->senha = $row['SENHA'];
                $this->email = $row['EMAIL'];
                $this->cpf = $row['CPF'];
                return true;
            }
        } catch (PDOException $e) {
            error_log("Database error: " . $e->getMessage());
        }
        return false;
    }

    public function update() {
        $stmt = $this->pdo->prepare("UPDATE Usuario SET LOGIN = :login, SENHA = :senha, EMAIL = :email, CPF = :cpf WHERE IDUSUARIO = :idUsuario");
        return $stmt->execute([
            ':login' => $this->login,
            ':senha' => $this->senha,
            ':email' => $this->email,
            ':cpf' => $this->cpf,
            ':idUsuario' => $this->idUsuario
        ]);
    }

    public function delete($idUsuario) {
        $stmt = $this->pdo->prepare("DELETE FROM Usuario WHERE IDUSUARIO = :idUsuario");
        return $stmt->execute([':idUsuario' => $idUsuario]);
    }

    public static function verificarAutenticacao() {
        session_start();
        if (isset($_SESSION['idUsuario'])) {
            return $_SESSION['idUsuario'];
        }
        return false;
    }
}
?>
