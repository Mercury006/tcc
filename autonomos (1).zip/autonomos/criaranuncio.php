<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Criar Anúncio</title>
    <link rel="stylesheet" href="./assets/style.css">
    <link rel="stylesheet" href="./assets/stylecriaranuncio.css">
</head>
<body>
    <?php
    session_start();
    if (!isset($_SESSION['idUsuario'])) {
        echo "<script>alert('Você precisa estar logado para acessar esta página.');window.location.href = 'login.php';</script>";
        exit();
    } ?>
    <nav class="nav">
        <a href="index.php"><img class="nav-logo" src="./assets/img/title.svg"></a>
        <ul class="nav-items">
            <li class="nav-item" id="nav-Nossos-servicos"><a href="home.php">Nossos serviços</a></li>
            <li class="nav-item" id="nav-Criar-anuncio"><a href="criaranuncio.php">Criar um anúncio</a></li>
            <li class="nav-item"><a href="perfil.php">Perfil</a></li>
        </ul>
    </nav>

    <div class="container">
        <form class="formulario-criar-anuncio" id="file-upload-form" action="processa_anuncio.php" method="post" enctype="multipart/form-data">
            <div class="left">
                <div class="form-group">
                    <label for="nome">Nome:</label>
                    <input type="text" id="nome" name="nome" placeholder="Insira seu Nome: " maxlength="100" required>
                </div>
                <div class="form-group">
                    <label for="trabalho">Área de Trabalho:</label>
                    <input type="text" id="trabalho" name="trabalho" placeholder="Ex: Tecnologia" maxlength="100" required>
                </div>
                <div class="form-group">
                    <label for="especializacao">Especialização:</label>
                    <input type="text" id="especializacao" name="especializacao" placeholder="Ex: Desenvolvedor Web" maxlength="50" required>
                </div>
                <div class="form-group">
                    <label for="telefone">Contato:</label>
                    <input type="text" id="telefone" name="telefone" placeholder="Ex: (11) 99999-9999" maxlength="20" required>
                </div>
                <div class="form-group">
                    <label for="descricao">Descrição:</label>
                    <input type="text" id="descricao" name="descricao" placeholder="Escreva a descrição aqui..." maxlength="500" required></input>
                    <button type="submit" class="submit-button">Enviar</button>
                </div>
            </div>
            <div class="right">
                <input type="file" id="fileInput" accept="image/*" name="imagem" required>
                <img id="imagePreview" src="" alt="Image Preview">
                <div class="form-group">
                    <label for="horarios">Horários Disponíveis:</label>
                    <input type="text" id="horarios" name="horarios" placeholder="Ex: 9h às 18h" maxlength="50" required>
                </div>
                <div class="form-group">
                    <label for="redesocial">Rede Social:</label>
                    <input type="text" id="redesocial" name="redesocial" placeholder="Ex: @Instagram" maxlength="100" required>
                </div>
                <div class="form-group">
                    <label for="local">Endereço:</label>
                    <input type="text" id="local" name="local" placeholder="Ex: Rua das Flores, 123" maxlength="100" required>
                </div>
                <br>
            </div>
        </form>
    </div>
    <script src="script.js"></script>
</body>
</html>
