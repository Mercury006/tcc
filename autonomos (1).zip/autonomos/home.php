<?php
require 'conexao.php';

// Consulta os anúncios
$sql = "SELECT * FROM anuncio";
$stmt = $conexao->prepare($sql);
$stmt->execute();
$anuncios = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Autônomos</title>
    <link rel="stylesheet" href="./assets/style.css">
    <link rel="stylesheet" href="./assets/stylehome.css">
</head>
<body>
    <nav class="nav">
        <a href="index.php"><img class="nav-logo" src="./assets/img/title.svg"></a>
        <ul class="nav-items">
            <li class="nav-item" id="nav-Nossos-servicos"><a href="home.php">Nossos serviços</a></li>
            <li class="nav-item" id="nav-Criar-anuncio"><a href="criaranuncio.php">Criar um anúncio</a></li>
            <li class="nav-item"><a href="perfil.php">Perfil</a></li>
        </ul>
    </nav>
    <main>
        <div class="search-bar"></div>
        <div class="anuncios">
            <?php foreach ($anuncios as $anuncio): ?>
                <a href="anuncioprofissional.php?idAnuncio=<?= $anuncio['IDANUNCIO'] ?>">
                    <div class="anuncio">
                    <div class="anuncio-img">
                              <?php 
                            // Verifica se a imagem existe e imprime o caminho da imagem para depuração
                            $imgPath = htmlspecialchars($anuncio['IMAGEM']);
                            if (file_exists($imgPath)) {
                                echo "<img src='$imgPath' alt='Imagem do anúncio'>";
                            } else {
                                echo "<!-- Caminho da imagem não encontrado: $imgPath -->";
                                echo "<img src='./assets/img/default.png' alt='Imagem padrão'>";
                            }
                            ?>
                        </div>
                        <div class="titulo-anuncio">    
                            <h1><?= htmlspecialchars($anuncio['NOME']) ?></h1>
                            <h2><?= htmlspecialchars($anuncio['TRABALHO']) ?></h2>
                        </div>
                        <div class="informacoes-anuncio">
                            <p class="distancia"><?= htmlspecialchars($anuncio['LOCAL']) ?></p>
                            <p class="avaliacao"><?= str_repeat('★', (int)$anuncio['IDAVALIACAO']) ?></p>
                        </div>
                        <div class="descricao"><?= htmlspecialchars($anuncio['ESPECIALIZACAO']) ?></div>
                    </div>  
                </a>
            <?php endforeach; ?>
        </div>
    </main>
</body>
</html>
