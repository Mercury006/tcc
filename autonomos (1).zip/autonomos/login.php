<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="./assets/stylelogin.css">
    <link rel="stylesheet" href="./assets/style.css">
</head>

<body>
    <div class="main-login">
        <div class="left-login">
            <h1>Faça login<br>E trabalhe conosco!</h1>
        </div>
        <div class="right-login">
            <div class="card-login">
                <h1>LOGIN</h1>
                <form action="processa_login.php" method="post">
                    <div class="textfield">
                        <label for="login">Usuário</label>
                        <input type="text" name="login" placeholder="Usuário
                        " required>
                    </div>
                    <div class="textfield">
                        <label for="senha">Senha</label>
                        <input type="password" name="senha" placeholder="Senha" required>
                    </div>
                    <button type="submit" class="btn-login">Login</button>
                </form>
                <p class="redirecionar-login">Não tem login? <a href="cadastro.php">Cadastro</a></p>
            </div>
        </div>
        <img class="login-image" src="./assets/img/imagem-efeito-gradiente.svg">
    </div>
</body>

</html>
