<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perfil</title>
    <link rel="stylesheet" href="./assets/style.css">
    <link rel="stylesheet" href="./assets/styleperfil.css">
</head>

<body>
    <?php
    // Inicia a sessão
    session_start();

    // Verifica se o usuário está logado
    if (!isset($_SESSION['idUsuario'])) {
        echo "<script>alert('Você precisa estar logado para acessar esta página.');window.location.href = 'login.php';</script>";
        exit();
    }

    // Inclui os arquivos das classes
    require "classeusuario.php";
    require "classeanuncio.php";
    require "conexao.php";

    // Obtém o ID do usuário da sessão
    $userId = $_SESSION['idUsuario'];


    $pdo = $conexao;

    $usuario = new Usuario($pdo);
    $anuncio = new Anuncio();

    // Tenta buscar os dados do usuário
    try {
        if (!$usuario->readById($userId)) {
            echo "<script>alert('Nenhum usuário encontrado.');window.location.href = 'login.php';</script>";
            exit();
        }
    } catch (PDOException $e) {
        echo "<script>alert('Erro ao buscar dados do usuário: " . $e->getMessage() . "');window.location.href = 'login.php';</script>";
        exit();
    }

    // Prepara e executa a consulta para buscar anúncios do usuário
    try {
        $ads = $anuncio->readAllByUserId($pdo, $userId);
    } catch (PDOException $e) {
        echo "<script>alert('Erro ao buscar anúncios do usuário: " . $e->getMessage() . "');window.location.href = 'login.php';</script>";
        exit();
    }
    ?>

    <nav class="nav">
        <a href="index.php"><img class="nav-logo" src="./assets/img/title.svg"></a>
        <ul class="nav-items">
            <li class="nav-item" id="nav-Nossos-servicos"><a href="home.php">Nossos serviços</a></li>
            <li class="nav-item" id="nav-Criar-anuncio"><a href="criaranuncio.php">Criar um anúncio</a></li>
            <li class="nav-item"><a href="perfil.php">Perfil</a></li>
        </ul>
    </nav>

    <div class="main">
        <h1>Perfil:</h1>
        <div>Nome: <?php echo htmlspecialchars($usuario->getLogin()); ?></div>
        <div>Email: <?php echo htmlspecialchars($usuario->getEmail()); ?></div>
        <div>CPF: <?php echo htmlspecialchars($usuario->getCpf()); ?></div>
        <br><br>
        <h1>Anúncios:</h1>
        <?php if ($ads): ?>
            <div class="anuncios">
                <?php foreach ($ads as $ad): ?>
                    <a href="anuncioprofissional.php?idAnuncio=<?= $ad['IDANUNCIO'] ?>">
                        <div class="anuncio">
                            <div class="anuncio-img">
                                <?php
                                // Verifica se a imagem existe
                                $imgPath = htmlspecialchars($ad['IMAGEM']);
                                if (file_exists($imgPath)) {
                                    echo "<img src='$imgPath' alt='Imagem do anúncio'>";
                                } else {
                                    echo "<!-- Caminho da imagem não encontrado: $imgPath -->";
                                    echo "<img src='./assets/img/default.png' alt='Imagem padrão'>";
                                }
                                ?>
                            </div>
                            <div class="titulo-anuncio">
                                <h1><?= htmlspecialchars($ad['NOME']) ?></h1>
                                <h2><?= htmlspecialchars($ad['TRABALHO']) ?></h2>
                            </div>
                            <div class="informacoes-anuncio">
                                <p class="distancia"><?= htmlspecialchars($ad['LOCAL']) ?></p>
                                <p class="avaliacao"><?= str_repeat('★', (int) $ad['IDAVALIACAO']) ?></p>
                            </div>
                            <div class="descricao"><?= htmlspecialchars($ad['ESPECIALIZACAO']) ?></div>
                        </div>
                    </a>
                <?php endforeach; ?>
            <?php else: ?>
                <p>Nenhum anúncio encontrado.</p>
            <?php endif; ?>
            </div>
        </div>
    </div>
</body>

</html>