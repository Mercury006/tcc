<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Perfil</title>
    <link rel="stylesheet" href="./assets/style.css">
    <link rel="stylesheet" href="./assets/styleperfil.css">
    <link rel="stylesheet" href="./assets/styleform.css">
</head>

<body>
    <?php
    session_start();
    if (!isset($_SESSION['idUsuario'])) {
        echo "<script>alert('Você precisa estar logado para acessar esta página.');window.location.href = 'login.php';</script>";
        exit();
    }

    require ('classeusuario.php');
    require ('conexao.php');

    $userId = $_SESSION['idUsuario'];
    $usuario = new Usuario($conexao);

    if ($usuario->readById($userId)) {
        $email = $usuario->getEmail();
        $cpf = $usuario->getCpf();
    } else {
        echo "<script>alert('Usuário não encontrado.');window.location.href = 'perfil.php';</script>";
        exit();
    }
    ?>

    <nav class="nav">
        <a href="index.php"><img class="nav-logo" src="./assets/img/title.svg"></a>
        <ul class="nav-items">
            <li class="nav-item" id="nav-Nossos-servicos"><a href="home.php">Nossos serviços</a></li>
            <li class="nav-item" id="nav-Criar-anuncio"><a href="criaranuncio.php">Criar um anúncio</a></li>
            <li class="nav-item"><a href="perfil.php">Perfil</a></li>
        </ul>
    </nav>

    <div class="main">
        <div class="card-login">
            <div class="textfield">
                <h1>Alterar Senha</h1>
                <form action="processa_edicao_senha.php" method="post">
                    <div class="textfield">
                        <label for="senha_atual">Senha Atual:</label>
                        <input type="password" id="senha_atual" name="senha_atual">
                    </div>
                    <div class="textfield">
                        <label for="senha">Nova Senha:</label>
                        <input type="password" id="senha" name="senha">
                    </div>
                    <div class="textfield">
                        <label for="confirmar_senha">Confirme a Nova Senha:</label>
                        <input type="password" id="confirmar_senha" name="confirmar_senha">
                    </div>
                    <button type="submit" class="submit-button">Salvar Alterações</button>
                </form>
            </div>
        </div>
</body>

</html>