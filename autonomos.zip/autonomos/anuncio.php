<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./assets/styleanuncio.css">
    <link rel="stylesheet" href="./assets/style.css">
</head>

<body>
    <nav class="nav">
        <a href="index.php"><img class="nav-logo" src="./assets/img/title.svg"></a>
        <ul class="nav-items">
            <li class="nav-item" id="nav-Nossos-servicos"><a href="home.php">Nossos serviços</a></li>
            <li class="nav-item" id="nav-Criar-anuncio"><a href="criaranuncio.php">Criar um anúncio</a></li>
            <li class="nav-item"><a href="perfil.php">Perfil</a></li>
        </ul>
    </nav>
    <main>
        <div class="search-bar"></div>
        <div class="anuncios">
            <div class="anuncio">
                <div class="anuncio-img"><img src="" alt=""></div>
                <div class="titulo-anuncio">
                    <h1>Nome</h1>
                    <h2>profissão</h2>
                </div>
                <div class="informacoes-anuncio">
                    <p class="distancia">99km</p>
                    <p class="avaliacao"> ★ ★ ★</p>
                </div>
                <div class="descricao">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Quos eaque
                    reiciendis voluptas blanditiis eveniet ipsam officia quo eum ex vero. Quas explicabo
                    autem,
                    eveniet vel aspernatur alias est perspiciatis culpa!
                </div>
            </div>
            <div class="main-container">
                <div class="first-infos">
                    <span class="nome">João Andrini</span>
                    <div class="avaliacao">
                        <span>Avaliação</span>
                        <span>★★★★★</span>
                    </div>
                    <button>Contatar</button>
                </div>
                <div class="imagens">

                </div>
                <div class="second-infos">
                    <div class="container1">
                        <div class="duracao">
                            <span>Duração</span>
                        </div>
                        <div class="preco">
                            <span>Preco</span>
                        </div>
                        <div class="local-servico">
                            <span>Local de Serviço</span>
                        </div>
                    </div>
                    <div class="container2">
                        <h2>Descrição:</h2>
                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eum, veniam placeat numquam, at
                            corrupti mollitia aut voluptatem sequi repellendus quo officia incidunt inventore tempora
                            eaque exercitationem voluptate voluptatum odio voluptas.</p>
                    </div>
                </div>
            </div>
</body>

</html>