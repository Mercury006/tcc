<?php
require 'conexao.php';

if (isset($_GET['idAnuncio'])) {
    $idAnuncio = $_GET['idAnuncio'];
    $sql = "SELECT * FROM anuncio WHERE IDANUNCIO = :idAnuncio";
    $stmt = $conexao->prepare($sql);
    $stmt->bindParam(':idAnuncio', $idAnuncio);
    $stmt->execute();
    $anuncio = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($anuncio) {
        $nome = htmlspecialchars($anuncio['NOME']);
        $redeSocial = htmlspecialchars($anuncio['REDESOCIAL']);
        $telefone = htmlspecialchars($anuncio['TELEFONE']);
        $email = htmlspecialchars($anuncio['EMAIL']);
        $trabalho = htmlspecialchars($anuncio['TRABALHO']);
        $especializacao = htmlspecialchars($anuncio['ESPECIALIZACAO']);
        $local = htmlspecialchars($anuncio['LOCAL']);
        $descricao = htmlspecialchars($anuncio['DESCRICAO']);
        $enderecoAnuncio = htmlspecialchars($anuncio['ENDERECOANUNCIO']);
        $horarios = htmlspecialchars($anuncio['HORARIOS']);
        $imagem = htmlspecialchars($anuncio['IMAGEM']);
        $idUsuario = htmlspecialchars($anuncio['IDUSUARIO']);
        ?>  

        <!DOCTYPE html>
        <html lang="pt-br">

        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title><?= $nome ?></title>
            <link rel="stylesheet" href="./assets/style.css">
            <link rel="stylesheet" href="./assets/styleanuncioprofissional.css">
        </head>

        <body>
            <nav class="nav">
                <a href="index.php"><img class="nav-logo" src="./assets/img/title.svg"></a>
                <ul class="nav-items">
                    <li class="nav-item" id="nav-Nossos-servicos"><a href="home.php">Nossos serviços</a></li>
                    <li class="nav-item" id="nav-Criar-anuncio"><a href="criaranuncio.php">Criar um anúncio</a></li>
                    <li class="nav-item"><a href="perfil.php">Perfil</a></li>
                </ul>
            </nav>
            <main>
                </div>
                <div class="main-container">
                    <div class="first-infos">
                        <h1 id="nome"><?= $nome ?></h1>
                        <h1 class="area-trabalho"><?= $trabalho ?></h1>
                        <a href="perfilpublico.php?idUsuario=<?= $idUsuario ?>"><h2 class="area-trabalho">Perfil</h2></a>

                    </div>
                    <div class="second-infos">
                        <img src="<?= $imagem ?>" alt="Imagem do anúncio" class="big-image">
                        <div class="info-right">
                            <h3>Rede Social:</h3>
                            <p><br> <?= $redeSocial ?></p>
                            <br>
                            <h3>Contato: </h3>
                            <p><br><?= $telefone ?></p>
                            <br>
                            <h3><?= $email ?></p>
                                <br>
                                <h3>Especialização:</h3>
                                <p><br> <?= $especializacao ?></p>
                                <br>
                                <h3>Local: </h3>
                                <p><br><?= $local ?></p>
                                <br>
                                <h3><?= $enderecoAnuncio ?></p>
                                    <br>
                                    <h3>Horários: </h3>
                                    <p><br><?= $horarios ?></p>
                        </div>
                    </div>
                    <div class="third-infos">
                        <div class="descricao info-bottom-left">
                            <h1> Descrição: </h1>
                            <p><br><?= $descricao ?></p>
                        </div>
                    </div>
                </div>
                </div>

            </main>
        </body>

        </html>

        <?php
    } else {
        header("Location: erro.php");
        exit();
    }
} else {
    header("Location: erro.php");
    exit();
}
?>