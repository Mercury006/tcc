<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Anúncio</title>
    <link rel="stylesheet" href="./assets/style.css">
    <link rel="stylesheet" href="./assets/stylecriaranuncio.css">
</head>
<body>
    <?php
    session_start();
    if (!isset($_SESSION['idUsuario'])) {
        echo "<script>alert('Você precisa estar logado para acessar esta página.');window.location.href = 'login.php';</script>";
        exit();
    }

    require('classeanuncio.php');
    require('conexao.php');
    $anuncio = new Anuncio();
    if (isset($_GET['idAnuncio'])) {
        $idAnuncio = $_GET['idAnuncio'];
        if ($anuncio->read($conexao, $idAnuncio)) {
            $nome = $anuncio->getNome();
            $trabalho = $anuncio->getTrabalho();
            $especializacao = $anuncio->getEspecializacao();
            $telefone = $anuncio->getTelefone();
            $descricao = $anuncio->getDescricao();
            $horarios = $anuncio->getHorarios();
            $redeSocial = $anuncio->getRedeSocial();
            $local = $anuncio->getLocal();
            $imagem = $anuncio->getImagem();
        } else {
            echo "<script>alert('Anúncio não encontrado.');window.location.href = 'perfil.php';</script>";
            exit();
        }
    } else {
        echo "<script>alert('ID de anúncio não fornecido.');window.location.href = 'perfil.php';</script>";
        exit();
    }
    ?>

    <nav class="nav">
        <a href="index.php"><img class="nav-logo" src="./assets/img/title.svg"></a>
        <ul class="nav-items">
            <li class="nav-item" id="nav-Nossos-servicos"><a href="home.php">Nossos serviços</a></li>
            <li class="nav-item" id="nav-Criar-anuncio"><a href="criaranuncio.php">Criar um anúncio</a></li>
            <li class="nav-item"><a href="perfil.php">Perfil</a></li>
        </ul>
    </nav>

    <div class="container">
        <form class="formulario-criar-anuncio" id="file-upload-form" action="processa_edicao_anuncio.php" method="post" enctype="multipart/form-data">
            <input type="hidden" name="idAnuncio" value="<?php echo $idAnuncio; ?>">
            <input type="hidden" name="imagem_atual" value="<?php echo htmlspecialchars($imagem); ?>">
            <div class="left">
                <div class="form-group">
                    <label for="nome">Nome:</label>
                    <input type="text" id="nome" name="nome" value="<?php echo htmlspecialchars($nome); ?>" maxlength="100" required>
                </div>
                <div class="form-group">
                    <label for="trabalho">Área de Trabalho:</label>
                    <input type="text" id="trabalho" name="trabalho" value="<?php echo htmlspecialchars($trabalho); ?>" maxlength="100" required>
                </div>
                <div class="form-group">
                    <label for="especializacao">Especialização:</label>
                    <input type="text" id="especializacao" name="especializacao" value="<?php echo htmlspecialchars($especializacao); ?>" maxlength="50" required>
                </div>
                <div class="form-group">
                    <label for="telefone">Contato:</label>
                    <input type="text" id="telefone" name="telefone" value="<?php echo htmlspecialchars($telefone); ?>" maxlength="20" required>
                </div>
                <div class="form-group">
                    <label for="descricao">Descrição:</label>
                    <textarea id="descricao" name="descricao" maxlength="500" required><?php echo htmlspecialchars($descricao); ?></textarea>
                    <button type="submit" class="submit-button">Atualizar</button>
                </div>
            </div>
            <div class="right">
                <input type="file" id="fileInput" accept="image/*" name="imagem">
                <img id="imagePreview" src="<?php echo htmlspecialchars($imagem); ?>" alt="Image Preview">
                <div class="form-group">
                    <label for="horarios">Horários Disponíveis:</label>
                    <input type="text" id="horarios" name="horarios" value="<?php echo htmlspecialchars($horarios); ?>" maxlength="50" required>
                </div>
                <div class="form-group">
                    <label for="redesocial">Rede Social:</label>
                    <input type="text" id="redesocial" name="redesocial" value="<?php echo htmlspecialchars($redeSocial); ?>" maxlength="100" required>
                </div>
                <div class="form-group">
                    <label for="local">Endereço:</label>
                    <input type="text" id="local" name="local" value="<?php echo htmlspecialchars($local); ?>" maxlength="100" required>
                </div>
                <br>
            </div>
        </form>
    </div>
    <script src="script.js"></script>
</body>
</html>
