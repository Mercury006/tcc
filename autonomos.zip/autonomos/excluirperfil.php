<?php
session_start();

if (!isset($_SESSION['idUsuario'])) {
    echo "<script>alert('Você precisa estar logado para acessar esta página.');window.location.href = 'login.php';</script>";
    exit();
}

require('classeusuario.php');
require('conexao.php');


$usuario = new Usuario($conexao);

// Verifica se o usuário confirmou a exclusão do perfil
if (isset($_POST['confirmacao'])) {
    $userId = $_SESSION['idUsuario'];

    // Excluir o perfil do usuário
    if ($usuario->delete($userId)) {
        // Logout do usuário após excluir o perfil
        session_destroy();
        echo "<script>alert('Perfil excluído com sucesso!');window.location.href = 'index.php';</script>";
        exit();
    } else {
        echo "<script>alert('Erro ao excluir o perfil.');window.location.href = 'perfil.php';</script>";
        exit();
    }
}


// Página de confirmação para exclusão do perfil
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Excluir Perfil</title>
    <link rel="stylesheet" href="./assets/style.css">
    <link rel="stylesheet" href="./assets/styleform.css">
    <style>
        body{
            height: 100vh;
            overflow: hidden;
        }
        .main{
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100%;
            margin-top: -3em;
        }
        .textfield{
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 2em;
        }
        h1{
            font-size: 3em;
        }
    </style>
</head>

<body>
    <nav class="nav">
        <a href="index.php"><img class="nav-logo" src="./assets/img/title.svg"></a>
        <!-- Menu de navegação, ajuste conforme necessário -->
    </nav>

    <div class="main">
        <div class="card-login">
            <div class="textfield">
                <h1>Confirmação de Exclusão</h1>
                <p>Você tem certeza de que deseja excluir seu perfil? Esta ação não poderá ser desfeita.</p>
                <form action="excluirperfil.php" method="post">
                    <input type="hidden" name="confirmacao" value="true">
                    <button type="submit" class="btn-edit" style="background-color: #9C2E2E;">Confirmar Exclusão</button>
                    <a href="perfil.php" class="btn-edit">Cancelar</a>
                </form>
            </div>
        </div>
    </div>
</body>

</html>
