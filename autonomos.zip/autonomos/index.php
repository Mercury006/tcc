<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Autônomos</title>
    <link rel="stylesheet" href="./assets/styleindex.css">
    <link rel="stylesheet" href="./assets/style.css">
</head>

<body>
    <nav class="nav">
        <a href="index.php"><img class="nav-logo" src="./assets/img/title.svg"></a>
        <ul class="nav-items">
            <li class="nav-item" id="nav-Nossos-servicos"><a href="home.php">Nossos serviços</a></li>
            <li class="nav-item" id="nav-Criar-anuncio"><a href="criaranuncio.php">Criar um anúncio</a></li>
        </ul>
    </nav>
    
    <img class="index-image" src="./assets/img/imagem-efeito-gradiente.svg">
    <img class="index-image2" src="./assets/img/imagem-efeito-gradiente.svg">
    <div class="main">
        <div class="informacoes">
            <h1>Encontre os melhores serviços pra você!</h1>
            <h2>Conectando profissionais e demandantes</h2>
            <a href="login.php"><button>Entrar</button></a>
        </div>
        <div class="imagem"><img src="./assets/img/foto.png" alt=""></div>
    </div>
</body>

</html>
