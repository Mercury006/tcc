<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perfil</title>
    <link rel="stylesheet" href="./assets/style.css">
    <link rel="stylesheet" href="./assets/styleperfil.css">
</head>

<body>
    <?php
    // Inicia a sessão
    session_start();

    // Verifica se o usuário está logado
    if (!isset($_SESSION['idUsuario'])) {
        echo "<script>alert('Você precisa estar logado para acessar esta página.');window.location.href = 'login.php';</script>";
        exit();
    }

    // Inclui os arquivos das classes
    require "classeusuario.php";
    require "classeanuncio.php";
    require "conexao.php";

    // Obtém o ID do usuário da sessão
    $userId = $_SESSION['idUsuario'];


    $pdo = $conexao;

    $usuario = new Usuario($pdo);
    $anuncio = new Anuncio();

    // Tenta buscar os dados do usuário
    try {
        if (!$usuario->readById($userId)) {
            echo "<script>alert('Nenhum usuário encontrado.');window.location.href = 'login.php';</script>";
            exit();
        }
    } catch (PDOException $e) {
        echo "<script>alert('Erro ao buscar dados do usuário: " . $e->getMessage() . "');window.location.href = 'login.php';</script>";
        exit();
    }

    // Prepara e executa a consulta para buscar anúncios do usuário
    try {
        $ads = $anuncio->readAllByUserId($pdo, $userId);
    } catch (PDOException $e) {
        echo "<script>alert('Erro ao buscar anúncios do usuário: " . $e->getMessage() . "');window.location.href = 'login.php';</script>";
        exit();
    }
    ?>

    <nav class="nav">
        <a href="index.php"><img class="nav-logo" src="./assets/img/title.svg"></a>
        <ul class="nav-items">
            <li class="nav-item" id="nav-Nossos-servicos"><a href="home.php">Nossos serviços</a></li>
            <li class="nav-item" id="nav-Criar-anuncio"><a href="criaranuncio.php">Criar um anúncio</a></li>
            <li class="nav-item"><a href="perfil.php">Perfil</a></li>
        </ul>
    </nav>

    <div class="main">
        <div class="left">
            <h1 class="title"><?php echo htmlspecialchars($usuario->getLogin());?></h1>
            <div class="info-perfil" id="email-perfil"><b>Email:</b> <?php echo htmlspecialchars($usuario->getEmail()); ?></div>
            <div class="info-perfil" id="cpf-perfil"><b>CPF:</b> <?php echo htmlspecialchars($usuario->getCpf()); ?></div>
            <a href="editarusuario.php"><button  class="btn-edit">Editar Perfil</button></a>
            <a href="excluirperfil.php"><button  class="btn-edit" style="background-color: #9C2E2E;">Excluir Perfil</button></a>
        </div>
        <div class="right">
            <h1 class="title">Anúncios:</h1>
            <?php if ($ads): ?>
                <div class="anuncios">
                    <?php foreach ($ads as $ad): ?>
                        <a href="anuncioprofissional.php?idAnuncio=<?= $ad['IDANUNCIO'] ?>" style="display: block;">
                            <div class="anuncio">
                                <div class="anuncio-img">
                                    <?php
                                    $imgPath = htmlspecialchars($ad['IMAGEM']);
                                    if (file_exists($imgPath)) {
                                        echo "<img src='$imgPath' alt='Imagem do anúncio'>";
                                    } else {
                                        echo "<img src='./assets/img/default.png' alt='Imagem padrão'>";
                                    }
                                    ?>
                                </div>
                                <div class="titulo-anuncio">
                                    <h1><?= htmlspecialchars($ad['NOME']) ?></h1>
                                    <h2><?= htmlspecialchars($ad['TRABALHO']) ?></h2>
                                </div>
                                <div class="descricao">
                                    <a href="editaranuncio.php?idAnuncio=<?= $ad['IDANUNCIO'] ?>"><button class="btn-edit" id="btn-editar-anuncio">Editar</button></a>
                                    <a href="excluiranuncio.php?idAnuncio=<?= $ad['IDANUNCIO'] ?>"
                                        onclick="return confirm('Tem certeza que deseja excluir este anúncio?');"><button class="btn-edit" style="background-color: #9C2E2E;" id="btn-excluir-anuncio">Excluir</button></a>
                                </div>
                            </div>
                        </a>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p>Nenhum anúncio encontrado.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>

</body>

</html>