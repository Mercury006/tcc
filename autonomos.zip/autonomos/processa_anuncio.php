<?php
// Inclui o arquivo de configuração do banco de dados
require 'classeanuncio.php';
require 'conexao.php';
require 'classeusuario.php';

// Verifica se a sessão já está ativa antes de iniciar uma nova sessão
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

try {
    // Verifica se o usuário está autenticado
    $idUsuario = Usuario::verificarAutenticacao();
    if (!$idUsuario) {
        echo "Usuário não autenticado.";
        exit; // Encerra o script se o usuário não estiver autenticado
    }

    // Verifica se o formulário foi enviado
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        // Instancia a classe Anuncio
        $anuncio = new Anuncio();

        // Define os atributos do objeto com os valores recebidos do formulário
        $anuncio->setIdUsuario($idUsuario);
        $anuncio->setNome($_POST['nome']);
        $anuncio->setRedeSocial($_POST['redesocial']);
        $anuncio->setTelefone($_POST['telefone']);
        $anuncio->setEmail(""); // Adapte conforme necessário
        $anuncio->setTrabalho($_POST['trabalho']);
        $anuncio->setEspecializacao($_POST['especializacao']);
        $anuncio->setLocal($_POST['local']);
        $anuncio->setDescricao($_POST['descricao']);
        $anuncio->setHorarios($_POST['horarios']);

        // Diretório de destino para upload das imagens
        $targetDir = "uploads/";
        // Caminho do arquivo de destino
        $targetFile = $targetDir . uniqid() . '_' . basename($_FILES["imagem"]["name"]);
        // Verifica o status do upload
        $uploadOk = 1;
        // Tipo de arquivo da imagem
        $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

        // Verifica se o arquivo é uma imagem real
        $check = getimagesize($_FILES["imagem"]["tmp_name"]);
        if ($check !== false) {
            $uploadOk = 1;
        } else {
            echo "O arquivo não é uma imagem.";
            $uploadOk = 0;
        }

        // Verifica se o tamanho do arquivo é aceitável
        if ($_FILES["imagem"]["size"] > 5000000) { // 5MB máximo
            echo "Desculpe, o arquivo é muito grande.";
            $uploadOk = 0;
        }

        // Permite apenas certos formatos de arquivo
        if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif") {
            echo "Desculpe, apenas arquivos JPG, JPEG, PNG e GIF são permitidos.";
            $uploadOk = 0;
        }

        // Verifica se $uploadOk é 0 devido a um erro
        if ($uploadOk == 0) {
            echo "Desculpe, seu arquivo não foi enviado.";
        // Se tudo estiver ok, tenta fazer o upload do arquivo
        } else {
            if (move_uploaded_file($_FILES["imagem"]["tmp_name"], $targetFile)) {
                // Define o caminho da imagem no objeto anúncio
                $anuncio->setImagem($targetFile);
                
                // Chama o método create para inserir os dados no banco de dados
                if ($anuncio->create($conexao)) {
                    echo "<script>alert('Anúncio criado com sucesso!');window.location.href = 'home.php';</script>";
                } else {
                    echo "Falha ao criar o anúncio.";
                }
            } else {
                echo "Desculpe, houve um erro ao enviar seu arquivo.";
            }
        }
    } else {
        echo "Método de requisição inválido.";
    }
} catch (PDOException $e) {
    echo "Erro de conexão: " . $e->getMessage();
}
?>
