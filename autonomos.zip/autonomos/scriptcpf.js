document.getElementById('cpf').addEventListener('input', function (e) {
    let cpf = e.target.value.replace(/\D/g, '');
    cpf = cpf.replace(/(\d{3})(\d)/, '$1.$2');
    cpf = cpf.replace(/(\d{3})(\d)/, '$1.$2');
    cpf = cpf.replace(/(\d{3})(\d{1,2})$/, '$1-$2');
    e.target.value = cpf;
});

document.getElementById('formCadastro').addEventListener('submit', function (e) {
    const cpf = document.getElementById('cpf').value.replace(/\D/g, '');
    if (!validateCPF(cpf)) {
        e.preventDefault();
        document.getElementById('cpfError').textContent = 'CPF inválido';
    } else {
        document.getElementById('cpfError').textContent = '';
    }
});

function validateCPF(cpf) {
    if (cpf.length !== 11) {
        return false;
    }

    let sum = 0;
    let remainder;
    
    if (cpf === "00000000000") return false;
    
    for (let i = 1; i <= 9; i++) {
        sum = sum + parseInt(cpf.substring(i - 1, i)) * (11 - i);
    }
    
    remainder = (sum * 10) % 11;
    
    if ((remainder === 10) || (remainder === 11)) remainder = 0;
    if (remainder !== parseInt(cpf.substring(9, 10))) return false;
    
    sum = 0;
    
    for (let i = 1; i <= 10; i++) {
        sum = sum + parseInt(cpf.substring(i - 1, i)) * (12 - i);
    }
    
    remainder = (sum * 10) % 11;
    
    if ((remainder === 10) || (remainder === 11)) remainder = 0;
    if (remainder !== parseInt(cpf.substring(10, 11))) return false;
    
    return true;
}
