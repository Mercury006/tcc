<?php
require 'conexao.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $image = file_get_contents($_FILES['image']['tmp_name']);
        
        $sql = "INSERT INTO anuncio (IMAGEM) VALUES (:image)";
        $stmt = $conexao->prepare($sql);
        $stmt->bindParam(':image', $image, PDO::PARAM_LOB);

        if ($stmt->execute()) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Erro ao salvar imagem no banco de dados.']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Nenhuma imagem enviada ou erro no upload.']);
    }
}
?>
