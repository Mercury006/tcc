<?php
require 'conexao.php';
require "classeavaliacao.php";

if (isset($_GET['idAnuncio'])) {
    $idAnuncio = $_GET['idAnuncio'];

    $avaliacao = new Avaliacao($conexao);
    $mediaAvaliacao = $avaliacao->readByAnuncioId($idAnuncio);

    $sql = "SELECT * FROM anuncio WHERE IDANUNCIO = :idAnuncio";
    $stmt = $conexao->prepare($sql);
    $stmt->bindParam(':idAnuncio', $idAnuncio, PDO::PARAM_INT);
    $stmt->execute();
    $anuncio = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($anuncio) {
        $nome = htmlspecialchars($anuncio['NOME']);
        $redeSocial = htmlspecialchars($anuncio['REDESOCIAL']);
        $telefone = htmlspecialchars($anuncio['TELEFONE']);
        $email = htmlspecialchars($anuncio['EMAIL']);
        $trabalho = htmlspecialchars($anuncio['TRABALHO']);
        $especializacao = htmlspecialchars($anuncio['ESPECIALIZACAO']);
        $local = htmlspecialchars($anuncio['LOCAL']);
        $descricao = htmlspecialchars($anuncio['DESCRICAO']);
        $enderecoAnuncio = htmlspecialchars($anuncio['ENDERECOANUNCIO']);
        $horarios = htmlspecialchars($anuncio['HORARIOS']);
        $imagemCapa = htmlspecialchars($anuncio['IMAGEMCAPA']);
        $imagensAdicionais = isset($anuncio['IMAGENSADICIONAIS']) ? explode(',', $anuncio['IMAGENSADICIONAIS']) : [];
        $idUsuario = htmlspecialchars($anuncio['IDUSUARIO']);
        $descricaoSimples = htmlspecialchars($anuncio['DESCRICAOSIMPLES']);

        function renderStars($mediaAvaliacao)
        {
            $fullStars = floor($mediaAvaliacao);
            $halfStar = $mediaAvaliacao - $fullStars >= 0.5 ? 1 : 0;
            $emptyStars = 5 - $fullStars - $halfStar;

            $starsHtml = str_repeat('<span class="star">&#9733;</span>', $fullStars);
            $starsHtml .= str_repeat('<span class="star">&#9734;</span>', $halfStar);
            $starsHtml .= str_repeat('<span class="star">&#9734;</span>', $emptyStars);

            return $starsHtml;
        }
        ?>

        <!DOCTYPE html>
        <html lang="pt-br">

        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title><?= $nome ?></title>
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.css">
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick-theme.min.css">
            <link rel="stylesheet" href="./assets/style.css">
            <link rel="stylesheet" href="./assets/styleanuncioprofissional.css">
            <style>
                .stars {
                    display: inline-block;
                }

                .star {
                    color: #000;
                    /* Cor preta para as estrelas */
                    font-size: 1.5em;
                    /* Tamanho da estrela */
                    line-height: 1;
                }
            </style>
        </head>

        <body>
            <nav class="nav">
                <a href="index.php"><img class="nav-logo" src="./assets/img/title.svg"></a>
                <ul class="nav-items">
                    <li class="nav-item" id="nav-Nossos-servicos"><a href="home.php">Nossos serviços</a></li>
                    <li class="nav-item" id="nav-Criar-anuncio"><a href="criaranuncio.php">Criar um anúncio</a></li>
                    <li class="nav-item"><a href="perfil.php">Perfil</a></li>
                </ul>
            </nav>
            <main>
                <div class="main-container">
                    <div class="anuncio-header infos">
                        <div class="first-infos">
                            <h1 id="nome"><?= $nome ?></h1>
                            <h1 class="area-trabalho"><?= $trabalho ?></h1>
                            <h2><span class="stars"><?php echo renderStars($mediaAvaliacao); ?></span></h2>
                        </div>
                        <div class="second-infos-header">
                            <?php if (!empty($imagemCapa)): ?>
                                <img src="<?= $imagemCapa ?>" alt="Imagem de capa do anúncio" class="big-image"
                                    id="img-capaAnuncio">
                            <?php endif; ?>
                            <a href="perfilpublico.php?idUsuario=<?= $idUsuario ?>">
                                <h2 class="area-trabalho">Perfil</h2>
                            </a>
                        </div>
                    </div>
                    <div class="second-infos infos">
                        <?php if (!empty($imagensAdicionais)): ?>
                            <div class="carousel">
                                <?php foreach ($imagensAdicionais as $imagemAdicional): ?>
                                    <div><img src="<?= $imagemAdicional ?>" alt="Imagem adicional do anúncio"
                                            class="big-image-carousel"></div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                        <div class="info-right">
                            <h3>Rede Social:</h3>
                            <p><br> <?= $redeSocial ?></p>
                            <br>
                            <h3>Contato: </h3>
                            <p><br><?= $telefone ?></p>
                            <br>
                            <h3><?= $email ?></h3>
                            <br>
                            <h3>Especialização:</h3>
                            <p><br> <?= $especializacao ?></p>
                            <br>
                            <h3>Local: </h3>
                            <p><br><?= $local ?></p>
                            <br>
                            <h3><?= $enderecoAnuncio ?></h3>
                            <br>
                            <h3>Horários: </h3>
                            <p><br><?= $horarios ?></p>
                        </div>
                    </div>
                    <div class="third-infos infos">
                        <div class="descricao info-bottom-left">
                            <h1> Descrição: </h1>
                            <p><br><?= $descricao ?></p>
                        </div>
                        <div class="descricao-simples info-bottom-left">
                            <h2>Descrição Curta: </h2>
                            <p><br><?= $descricaoSimples ?></p>
                        </div>
                    </div>
                    <div class="avaliacao">
                        <a href="avaliaranuncio.php?idAnuncio=<?= $idAnuncio ?>" class="btn-avaliar">Avaliar Anúncio</a>
                    </div>
                </div>
            </main>
            <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
            <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.js"></script>
            <script>
                $(document).ready(function () {
                    $('.carousel').slick({
                        dots: true,
                        infinite: true,
                        speed: 300,
                        slidesToShow: 1,
                        adaptiveHeight: true
                    });
                });
            </script>
        </body>

        </html>
        <?php
    } else {
        header("Location: erro.php");
        exit();
    }
} else {
    header("Location: erro.php");
    exit();
}
?>