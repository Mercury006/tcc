<?php
require "conexao.php";
require "classeavaliacao.php";
require "classeanuncio.php";

session_start();

if (!isset($_SESSION['idUsuario'])) {
    echo "<script>alert('Você precisa estar logado para acessar esta página.');window.location.href = 'login.php';</script>";
    exit();
}

$pdo = $conexao;
$avaliacao = new Avaliacao($pdo);
$anuncio = new Anuncio();
$idAnuncio = $_GET['idAnuncio'];
$idUsuario = $_SESSION['idUsuario'];

// Verifica se o anúncio pertence ao usuário logado
$anuncio->read($pdo, $idAnuncio);
if ($anuncio->getIdUsuario() == $idUsuario) {
    echo "<script>alert('Você não pode avaliar seu próprio anúncio.');window.location.href = 'anuncioprofissional.php?idAnuncio=$idAnuncio';</script>";
    exit();
}

// Verifica se o usuário já avaliou o anúncio
if ($avaliacao->hasUserRatedAnuncio($idUsuario, $idAnuncio)) {
    echo "<script>alert('Você já avaliou este anúncio.');window.location.href = 'anuncioprofissional.php?idAnuncio=$idAnuncio';</script>";
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $avaliacao->setIdUsuario($idUsuario);
    $avaliacao->setNota($_POST['nota']);
    $avaliacao->setIdAnuncio($idAnuncio);
    if ($avaliacao->create()) {
        echo "<script>alert('Avaliação registrada com sucesso!');window.location.href = 'anuncioprofissional.php?idAnuncio=$idAnuncio';</script>";
    } else {
        echo "<script>alert('Erro ao registrar avaliação.');window.location.href = 'anuncioprofissional.php?idAnuncio=$idAnuncio';</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Avaliar Anúncio</title>
</head>
<body>
    <form method="post">
        <label for="nota">Nota (1-5):</label>
        <input type="number" id="nota" name="nota" min="1" max="5" required>
        <button type="submit">Enviar Avaliação</button>
    </form>
</body>
</html>
