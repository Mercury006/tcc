<?php
class Anuncio
{
    private $idAnuncio;
    private $idUsuario;
    private $idAvaliacao;
    private $redeSocial;
    private $telefone;
    private $email;
    private $trabalho;
    private $especializacao;
    private $local;
    private $descricao;
    private $horarios;
    private $nome;
    private $imagemCapa;
    private $imagensAdicionais;

    private $descricaoSimples;

    // Getters and Setters
    public function getIdAnuncio()
    {
        return $this->idAnuncio;
    }

    public function setIdAnuncio($idAnuncio)
    {
        $this->idAnuncio = $idAnuncio;
    }

    public function getIdUsuario()
    {
        return $this->idUsuario;
    }

    public function setIdUsuario($idUsuario)
    {
        $this->idUsuario = $idUsuario;
    }

    public function getIdAvaliacao()
    {
        return $this->idAvaliacao;
    }

    public function setIdAvaliacao($idAvaliacao)
    {
        $this->idAvaliacao = $idAvaliacao;
    }

    public function getRedeSocial()
    {
        return $this->redeSocial;
    }

    public function setRedeSocial($redeSocial)
    {
        $this->redeSocial = $redeSocial;
    }

    public function getTelefone()
    {
        return $this->telefone;
    }

    public function setTelefone($telefone)
    {
        $this->telefone = $telefone;
    }

    public function getEmail()
    {
        return $this->email;
    }

    public function setEmail($email)
    {
        $this->email = $email;
    }

    public function getTrabalho()
    {
        return $this->trabalho;
    }

    public function setTrabalho($trabalho)
    {
        $this->trabalho = $trabalho;
    }

    public function getEspecializacao()
    {
        return $this->especializacao;
    }

    public function setEspecializacao($especializacao)
    {
        $this->especializacao = $especializacao;
    }

    public function getLocal()
    {
        return $this->local;
    }

    public function setLocal($local)
    {
        $this->local = $local;
    }

    public function getDescricao()
    {
        return $this->descricao;
    }

    public function setDescricao($descricao)
    {
        $this->descricao = $descricao;
    }

    public function getHorarios()
    {
        return $this->horarios;
    }

    public function setHorarios($horarios)
    {
        $this->horarios = $horarios;
    }

    public function getImagemCapa()
    {
        return $this->imagemCapa;
    }

    public function setImagemCapa($imagemCapa)
    {
        $this->imagemCapa = $imagemCapa;
    }

    public function getNome()
    {
        return $this->nome;
    }

    public function setNome($nome)
    {
        $this->nome = $nome;
    }

    public function getImagensAdicionais()
    {
        return $this->imagensAdicionais;
    }

    public function setImagensAdicionais($imagensAdicionais)
    {
        $this->imagensAdicionais = $imagensAdicionais;
    }

    public function getDescricaoSimples()
    {
        return $this->descricaoSimples;
    }

    public function setDescricaoSimples($descricaoSimples)
    {
        $this->descricaoSimples = $descricaoSimples;
    }

    // CRUD Methods
    public function create($pdo)
    {
        $sql = "INSERT INTO anuncio (IDUSUARIO, IDAVALIACAO, NOME, REDESOCIAL, TELEFONE, EMAIL, TRABALHO, ESPECIALIZACAO, LOCAL, DESCRICAO, DESCRICAOSIMPLES, HORARIOS, IMAGEMCAPA, IMAGENSADICIONAIS) 
                VALUES (:idUsuario, :idAvaliacao, :nome, :redeSocial, :telefone, :email, :trabalho, :especializacao, :local, :descricao, :descricaoSimples, :horarios, :imagemCapa, :imagensAdicionais)";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':idUsuario', $this->idUsuario);
        $stmt->bindParam(':idAvaliacao', $this->idAvaliacao);
        $stmt->bindParam(':nome', $this->nome);
        $stmt->bindParam(':redeSocial', $this->redeSocial);
        $stmt->bindParam(':telefone', $this->telefone);
        $stmt->bindParam(':email', $this->email);
        $stmt->bindParam(':trabalho', $this->trabalho);
        $stmt->bindParam(':especializacao', $this->especializacao);
        $stmt->bindParam(':local', $this->local);
        $stmt->bindParam(':descricao', $this->descricao);
        $stmt->bindParam(':descricaoSimples', $this->descricaoSimples);
        $stmt->bindParam(':horarios', $this->horarios);
        $stmt->bindParam(':imagemCapa', $this->imagemCapa);
        $stmt->bindParam(':imagensAdicionais', $this->imagensAdicionais);
        return $stmt->execute();
    }


    public function read($pdo, $idAnuncio)
    {
        $sql = "SELECT * FROM anuncio WHERE IDANUNCIO = :idAnuncio";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':idAnuncio', $idAnuncio);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($result) {
            $this->idAnuncio = $result['IDANUNCIO'];
            $this->idUsuario = $result['IDUSUARIO'];
            $this->idAvaliacao = $result['IDAVALIACAO'];
            $this->redeSocial = $result['REDESOCIAL'];
            $this->telefone = $result['TELEFONE'];
            $this->email = $result['EMAIL'];
            $this->trabalho = $result['TRABALHO'];
            $this->especializacao = $result['ESPECIALIZACAO'];
            $this->local = $result['LOCAL'];
            $this->descricao = $result['DESCRICAO'];
            $this->descricaoSimples = $result['DESCRICAOSIMPLES'];
            $this->horarios = $result['HORARIOS'];
            $this->imagemCapa = $result['IMAGEMCAPA'];
            $this->imagensAdicionais = $result['IMAGENSADICIONAIS'];
            $this->nome = $result['NOME'];
            return true;
        }
        return false;
    }
    public function update($pdo)
    {
        $sql = "UPDATE anuncio SET 
                IDUSUARIO = :idUsuario, 
                IDAVALIACAO = :idAvaliacao, 
                REDESOCIAL = :redeSocial, 
                TELEFONE = :telefone, 
                EMAIL = :email, 
                TRABALHO = :trabalho, 
                ESPECIALIZACAO = :especializacao, 
                LOCAL = :local, 
                DESCRICAO = :descricao, 
                DESCRICAOSIMPLES = :descricaoSimples, 
                HORARIOS = :horarios, 
                IMAGEMCAPA = :imagemCapa, 
                IMAGENSADICIONAIS = :imagensAdicionais, 
                NOME = :nome 
            WHERE IDANUNCIO = :idAnuncio";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':idAnuncio', $this->idAnuncio);
        $stmt->bindParam(':idUsuario', $this->idUsuario);
        $stmt->bindParam(':idAvaliacao', $this->idAvaliacao);
        $stmt->bindParam(':redeSocial', $this->redeSocial);
        $stmt->bindParam(':telefone', $this->telefone);
        $stmt->bindParam(':email', $this->email);
        $stmt->bindParam(':trabalho', $this->trabalho);
        $stmt->bindParam(':especializacao', $this->especializacao);
        $stmt->bindParam(':local', $this->local);
        $stmt->bindParam(':descricao', $this->descricao);
        $stmt->bindParam(':descricaoSimples', $this->descricaoSimples);
        $stmt->bindParam(':horarios', $this->horarios);
        $stmt->bindParam(':imagemCapa', $this->imagemCapa);
        $stmt->bindParam(':imagensAdicionais', $this->imagensAdicionais);
        $stmt->bindParam(':nome', $this->nome);

        if ($stmt->execute()) {
            return true;
        } else {
            error_log("Erro ao atualizar o anúncio: " . implode(", ", $stmt->errorInfo()));
            return false;
        }
    }


    public function readImagensAdicionais($pdo, $idAnuncio)
    {
        $sql = "SELECT IMAGENSADICIONAIS FROM anuncio WHERE IDANUNCIO = :idAnuncio";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':idAnuncio', $idAnuncio);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($result) {
            $this->idAnuncio = $result['IDANUNCIO'];
            $this->imagensAdicionais = $result['IMAGENSADICIONAIS'];
            return true;
        }
        return false;
    }


    public function readAllByUserId($pdo, $idUsuario)
    {
        $sql = "SELECT * FROM anuncio WHERE IDUSUARIO = :idUsuario";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':idUsuario', $idUsuario);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }


    public function delete($pdo, $idAnuncio)
    {
        $sql = "DELETE FROM anuncio WHERE IDANUNCIO = :idAnuncio";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':idAnuncio', $idAnuncio);
        return $stmt->execute();
    }

    public function deleteByUserId($pdo, $idUsuario)
    {
        try {
            $sql = "DELETE FROM anuncio WHERE IDUSUARIO = :idUsuario";
            $stmt = $pdo->prepare($sql);
            $stmt->bindParam(':idUsuario', $idUsuario, PDO::PARAM_INT);
            return $stmt->execute();
        } catch (PDOException $e) {
            error_log("Erro ao excluir anúncios do usuário: " . $e->getMessage());
            return false;
        }
    }

    public function getMediaAvaliacao($pdo)
    {
        $sql = "SELECT AVG(a.NOTA) as media FROM avaliacao a INNER JOIN anuncio an ON a.IDANUNCIO = an.IDANUNCIO WHERE an.IDANUNCIO = :idAnuncio";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':idAnuncio', $this->idAnuncio);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['media'];
    }

    public function getMediaAvaliacaoUsuario($pdo)
    {
        $sql = "SELECT AVG(a.NOTA) as media FROM avaliacao a INNER JOIN anuncio an ON a.IDANUNCIO = an.IDANUNCIO WHERE an.IDUSUARIO = :idUsuario";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':idUsuario', $this->idUsuario);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['media'];
    }
}
