<?php class Avaliacao {
    private $idAvaliacao;
    private $idUsuario;
    private $nota;
    private $pdo;
    private $idAnuncio;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    // Getters and Setters
    public function getIdAvaliacao() {
        return $this->idAvaliacao;
    }

    public function setIdAvaliacao($idAvaliacao) {
        $this->idAvaliacao = $idAvaliacao;
    }

    public function getIdUsuario() {
        return $this->idUsuario;
    }

    public function setIdUsuario($idUsuario) {
        $this->idUsuario = $idUsuario;
    }

    public function getNota() {
        return $this->nota;
    }

    public function setNota($nota) {
        $this->nota = $nota;
    }

    public function getIdAnuncio() {
        return $this->idAnuncio;
    }

    public function setIdAnuncio($idAnuncio) {
        $this->idAnuncio = $idAnuncio;
    }

    // CRUD Operations
    public function create() {
        $sql = "INSERT INTO avaliacao (IDUSUARIO, IDANUNCIO, NOTA) VALUES (:idUsuario, :idAnuncio, :nota)";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindParam(':idUsuario', $this->idUsuario);
        $stmt->bindParam(':idAnuncio', $this->idAnuncio);
        $stmt->bindParam(':nota', $this->nota);
        return $stmt->execute();
    }

    public function readByAnuncioId($idAnuncio) {
        $sql = "SELECT AVG(NOTA) as media FROM avaliacao WHERE IDANUNCIO = :idAnuncio";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindParam(':idAnuncio', $idAnuncio, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC)['media'];
    }

    public function readByUserId($idUsuario) {
        $sql = "SELECT AVG(NOTA) as media FROM avaliacao WHERE IDUSUARIO = :idUsuario";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindParam(':idUsuario', $idUsuario, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC)['media'];
    }

    public function readMediaByAnuncioUserId($idUsuario) {
        $sql = "SELECT AVG(avaliacao.NOTA) as media
                FROM avaliacao
                INNER JOIN anuncio ON avaliacao.IDANUNCIO = anuncio.IDANUNCIO
                WHERE anuncio.IDUSUARIO = :idUsuario";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindParam(':idUsuario', $idUsuario, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC)['media'];
    }

    // Método para verificar se o usuário já avaliou um anúncio
    public function hasUserRatedAnuncio($idUsuario, $idAnuncio) {
        $sql = "SELECT COUNT(*) as count FROM avaliacao WHERE IDUSUARIO = :idUsuario AND IDANUNCIO = :idAnuncio";
        $stmt = $this->pdo->prepare($sql);
        $stmt->bindParam(':idUsuario', $idUsuario, PDO::PARAM_INT);
        $stmt->bindParam(':idAnuncio', $idAnuncio, PDO::PARAM_INT);
        $stmt->execute();
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        return $result['count'] > 0;
    }
}
?>
