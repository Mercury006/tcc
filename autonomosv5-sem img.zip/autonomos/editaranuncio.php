<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Anúncio</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="./assets/style.css">
    <link rel="stylesheet" href="./assets/stylecriaranuncio.css">
    <link rel="stylesheet" href="./assets/styleeditaranuncio.css">
</head>

<body>
    <nav class="nav">
        <a href="index.php"><img class="nav-logo" src="./assets/img/title.svg"></a>
        <ul class="nav-items">
            <li class="nav-item" id="nav-Nossos-servicos"><a href="home.php">Nossos serviços</a></li>
            <li class="nav-item" id="nav-Criar-anuncio"><a href="criaranuncio.php">Criar um anúncio</a></li>
            <li class="nav-item"><a href="perfil.php">Perfil</a></li>
        </ul>
    </nav>

    <div class="container">
        <?php
        session_start();
        if (!isset($_SESSION['idUsuario'])) {
            echo "<script>alert('Você precisa estar logado para acessar esta página.');window.location.href = 'login.php';</script>";
            exit();
        }

        require ('classeanuncio.php');
        require ('conexao.php');

        $anuncio = new Anuncio();
        if (isset($_GET['idAnuncio'])) {
            $idAnuncio = $_GET['idAnuncio'];
            if ($anuncio->read($conexao, $idAnuncio)) {
                $nome = $anuncio->getNome();
                $trabalho = $anuncio->getTrabalho();
                $especializacao = $anuncio->getEspecializacao();
                $telefone = $anuncio->getTelefone();
                $descricao = $anuncio->getDescricao();
                $horarios = $anuncio->getHorarios();
                $redeSocial = $anuncio->getRedeSocial();
                $local = $anuncio->getLocal();
                $imagensAdicionais = $anuncio->getImagensAdicionais();
                $imagemCapa = $anuncio->getImagemCapa();
            } else {
                echo "<script>alert('Anúncio não encontrado.');window.location.href = 'perfil.php';</script>";
                exit();
            }
        } else {
            echo "<script>alert('ID de anúncio não fornecido.');window.location.href = 'perfil.php';</script>";
            exit();
        }
        ?>
        <form class="formulario-criar-anuncio" id="file-upload-form" action="processa_edicao_anuncio.php" method="post"
            enctype="multipart/form-data">
            <input type="hidden" name="idAnuncio" value="<?php echo $idAnuncio; ?>">
            <input type="hidden" name="imagem_atual" value="<?php echo htmlspecialchars($imagemCapa); ?>">
            <input type="hidden" name="imagens_adicionais_atuais"
                value="<?php echo htmlspecialchars($imagensAdicionais); ?>">

            <div class="left">
                <div class="form-group">
                    <label for="nome">Nome:</label>
                    <input type="text" id="nome" name="nome" value="<?php echo htmlspecialchars($nome); ?>"
                        maxlength="100" required>
                </div>
                <div class="form-group">
                    <label for="trabalho">Área de Trabalho:</label>
                    <input type="text" id="trabalho" name="trabalho" value="<?php echo htmlspecialchars($trabalho); ?>"
                        maxlength="100" required>
                </div>
                <div class="form-group">
                    <label for="especializacao">Especialização:</label>
                    <input type="text" id="especializacao" name="especializacao"
                        value="<?php echo htmlspecialchars($especializacao); ?>" maxlength="50" required>
                </div>
                <div class="form-group">
                    <label for="telefone">Contato:</label>
                    <input type="text" id="telefone" name="telefone" value="<?php echo htmlspecialchars($telefone); ?>"
                        maxlength="20" required>
                </div>
                <div class="form-group">
                    <label for="descricao">Descrição:</label>
                    <textarea id="descricao" name="descricao" maxlength="500"
                        required><?php echo htmlspecialchars($descricao); ?></textarea>
                </div>
                <div class="form-group">
                    <label for="descricaoSimples">Descrição Simples:</label>
                    <input type="text" id="descricaoSimples" name="descricaoSimples"
                        value="<?php echo htmlspecialchars($anuncio->getDescricaoSimples()); ?>" maxlength="100"
                        required>
                </div>
            </div>
            
            <div class="right">
                <div class="form-group">
                    <label for="horarios">Horários Disponíveis:</label>
                    <input type="text" id="horarios" name="horarios" value="<?php echo htmlspecialchars($horarios); ?>"
                    maxlength="50" required>
                </div>
                <div class="form-group">
                    <label for="redesocial">Rede Social:</label>
                    <input type="text" id="redesocial" name="redesocial"
                    value="<?php echo htmlspecialchars($redeSocial); ?>" maxlength="100" required>
                </div>
                <div class="form-group">
                    <label for="local">Endereço:</label>
                    <input type="text" id="local" name="local" value="<?php echo htmlspecialchars($local); ?>"
                    maxlength="100" required>
                </div>
                
                <div class="form-group">
                    <label for="imagemCapa">Imagem de Capa:</label><br>
                    <img id="imagePreview" src="<?php echo htmlspecialchars($imagemCapa); ?>" alt="Image Preview"
                    style="max-width: 200px; margin-bottom: 10px; border-radius: 15px;"><br>
                    <input type="file" id="imagemCapa" accept="image/*" name="imagemCapa">
                </div>
                
                <div class="form-group">
                    <label for="imagensAdicionais">Imagens Adicionais:</label>
                    
                    <div id="carouselImagensAdicionais" class="carousel slide" data-ride="carousel">
                        <div class="carousel-inner">
                            <?php
                            $imagensArray = explode(',', $imagensAdicionais);
                            foreach ($imagensArray as $index => $imagem) {
                                $activeClass = $index === 0 ? 'active' : '';
                                echo '<div class="carousel-item ' . $activeClass . ' carousel-item-atual">';
                                echo '<img src="' . htmlspecialchars($imagem) . '" class="d-block w-100 img-carousel" alt="Imagem Adicional ' . $index . '">';
                                echo '<button type="button" class="btn btn-primary btn-sm editar-imagem" data-imagem="' . htmlspecialchars($imagem) . '" data-id-anuncio="' . htmlspecialchars($idAnuncio) . '" data-toggle="modal" data-target="#editarImagemModal">Editar</button>';
                                echo '</div>';
                            }
                            ?>
                        </div>
                        <a class="carousel-control-prev" href="#carouselImagensAdicionais" role="button"
                        data-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="sr-only">Anterior</span>
                    </a>
                    <a class="carousel-control-next" href="#carouselImagensAdicionais" role="button"
                    data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Próximo</span>
                </a>
            </div>
            <input type="file" name="imagensAdicionais[]" accept="image/*" multiple>
        </div>
    </div>
    <button type="submit" class="submit-button">Atualizar</button>
</form>
</div>

    <div class="modal fade" id="editarImagemModal" tabindex="-1" role="dialog" aria-labelledby="editarImagemModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <form id="formEditarImagem" enctype="multipart/form-data" action="processa_edicao_imagem_adicional.php"
                    method="post">
                    <div class="modal-header">
                        <h5 class="modal-title" id="editarImagemModalLabel">Editar Imagem</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" id="idAnuncioModal" name="idAnuncio" value="">
                        <input type="hidden" id="imagemAtualModal" name="imagemAtual">
                        <div class="form-group">
                            <label for="novaImagem">Selecione uma nova imagem:</label>
                            <input type="file" class="form-control-file" id="novaImagem" name="novaImagem"
                                accept="image/*">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-primary">Salvar Mudanças</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@1.16.0/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        $(document).ready(function () {
            $('.editar-imagem').click(function () {
                var imagemAtual = $(this).data('imagem');
                var idAnuncio = $(this).data('id-anuncio');

                $('#idAnuncioModal').val(idAnuncio);
                $('#imagemAtualModal').val(imagemAtual);
            });

            $('#imagemCapa').change(function () {
                var input = this;
                if (input.files && input.files[0]) {
                    var reader = new FileReader();
                    reader.onload = function (e) {
                        $('#imagePreview').attr('src', e.target.result);
                    }
                    reader.readAsDataURL(input.files[0]);
                }
            });

            $('#editarImagemModal').on('keypress', function (e) {
                var key = e.which || e.keyCode;
                if (key === 13) {
                    e.preventDefault();
                }
            });

            $('#addImageButton').click(function () {
                $('#additionalImagesContainer').append('<div class="form-group"><input type="file" name="imagensAdicionais[]" accept="image/*" class="form-control-file" multiple></div>');
            });
        });
    </script>
</body>

</html>