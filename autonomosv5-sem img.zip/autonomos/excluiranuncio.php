<?php
session_start();
if (!isset($_SESSION['idUsuario'])) {
    echo "<script>alert('Você precisa estar logado para acessar esta página.');window.location.href = 'login.php';</script>";
    exit();
}

require('classeanuncio.php');
require('conexao.php');

$anuncio = new Anuncio();
$idAnuncio = $_GET['idAnuncio'];

if ($anuncio->delete($conexao, $idAnuncio)) {
    echo "<script>alert('Anúncio excluído com sucesso!');window.location.href = 'perfil.php';</script>";
} else {
    echo "<script>alert('Erro ao excluir anúncio.');window.location.href = 'perfil.php';</script>";
}
?>
