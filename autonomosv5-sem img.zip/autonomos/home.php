<?php
require 'conexao.php';

// Função para renderizar estrelas
function renderStars($mediaAvaliacao)
{
    $fullStars = floor($mediaAvaliacao);
    $halfStar = $mediaAvaliacao - $fullStars >= 0.5 ? 1 : 0;
    $emptyStars = 5 - $fullStars - $halfStar;

    $starsHtml = str_repeat('<span class="star">&#9733;</span>', $fullStars);
    $starsHtml .= str_repeat('<span class="star">&#9734;</span>', $halfStar);
    $starsHtml .= str_repeat('<span class="star">&#9734;</span>', $emptyStars);

    return $starsHtml;
}

// Parâmetro de pesquisa
$search = isset($_GET['search']) ? $_GET['search'] : '';

// Consulta os anúncios com base na pesquisa, incluindo a média das avaliações
$sql = "SELECT a.*, COALESCE(AVG(av.NOTA), 0) as mediaAvaliacao
        FROM anuncio a
        LEFT JOIN avaliacao av ON a.IDANUNCIO = av.IDANUNCIO
        WHERE a.NOME LIKE :search OR a.ESPECIALIZACAO LIKE :search OR a.TRABALHO LIKE :search
        GROUP BY a.IDANUNCIO";
$stmt = $conexao->prepare($sql);
$searchParam = '%' . $search . '%';
$stmt->bindParam(':search', $searchParam, PDO::PARAM_STR);
$stmt->execute();
$anuncios = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Autônomos</title>
    <link rel="stylesheet" href="./assets/style.css">
    <link rel="stylesheet" href="./assets/stylehome.css">
    <style>
        .stars {
            display: inline-block;
        }

        .star {
            color: #000;
            font-size: 1.5em;
            line-height: 1;
        }
    </style>
</head>
<body>
    <nav class="nav">
        <a href="index.php"><img class="nav-logo" src="./assets/img/title.svg"></a>
        <ul class="nav-items">
            <li class="nav-item" id="nav-Nossos-servicos"><a href="home.php">Nossos serviços</a></li>
            <li class="nav-item" id="nav-Criar-anuncio"><a href="criaranuncio.php">Criar um anúncio</a></li>
            <li class="nav-item"><a href="perfil.php">Perfil</a></li>
        </ul>
    </nav>
    <main>
        <div class="search-bar">
            <form method="GET" action="home.php">
                <input type="text" name="search" placeholder="Pesquisar por especialização, nome ou profissão...">
                <button type="submit">Pesquisar</button>
            </form>
        </div> 
        <div class="anuncios">
            <?php if ($anuncios): ?>
                <?php foreach ($anuncios as $anuncio): ?>
                    <a href="anuncioprofissional.php?idAnuncio=<?= $anuncio['IDANUNCIO'] ?>">
                        <div class="anuncio">
                            <div class="anuncio-img">
                                <?php 
                                $imgPath = htmlspecialchars($anuncio['IMAGEMCAPA']);
                                if (file_exists($imgPath)) {
                                    echo "<img src='$imgPath' alt='Imagem do anúncio'>";
                                } else {
                                    echo "<!-- Caminho da imagem não encontrado: $imgPath -->";
                                    echo "<img src='./assets/img/default.png' alt='Imagem padrão'>";
                                }
                                ?>
                            </div>
                            <div class="titulo-anuncio">    
                                <h1><?= htmlspecialchars($anuncio['NOME']) ?></h1>
                                <h2><?= htmlspecialchars($anuncio['TRABALHO']) ?></h2>
                            </div>
                            <div class="informacoes-anuncio">
                                <p class="distancia"><?= htmlspecialchars($anuncio['LOCAL']) ?></p>
                                <p class="avaliacao">
                                    <span class="stars"><?php echo renderStars($anuncio['mediaAvaliacao']); ?></span>
                                </p>
                            </div>
                            <div class="descricao"><?= htmlspecialchars($anuncio['DESCRICAOSIMPLES']) ?></div>
                        </div>
                    </a>
                <?php endforeach; ?>
            <?php else: ?>
                <p>Nenhum anúncio encontrado.</p>
            <?php endif; ?>
        </div>
    </main>
</body>
</html>
