<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perfil Público</title>
    <link rel="stylesheet" href="./assets/style.css">
    <link rel="stylesheet" href="./assets/styleperfil.css">

    <style>
        html{
            overflow-x: hidden;
        }
        .main{
            flex-direction: column;
            justify-content: center;
            align-items: center;
        }
        .anuncios{
            min-width: 100vw;
            padding: 3em;
            justify-content: space-evenly;
        }
        .anuncio{
            flex: 1;
        }
        a{
            width: 14em;
            height: fit-content;
        }
        .stars {
            display: inline-block;
        }
        .star {
            color: #000; /* Cor preta para as estrelas */
            font-size: 1.5em; /* Tamanho da estrela */
            line-height: 1;
        }
    </style>
</head>
<body>
    <?php
    require "classeusuario.php";
    require "classeanuncio.php";
    require "classeavaliacao.php";
    require "conexao.php";

    if (!isset($_GET['idUsuario'])) {
        echo "<script>alert('ID do usuário não fornecido.');window.location.href = 'index.php';</script>";
        exit();
    }

    $userId = $_GET['idUsuario'];

    $pdo = $conexao;
    $usuario = new Usuario($pdo);
    $ad = new Anuncio();
    $avaliacao = new Avaliacao($pdo);
    $mediaAvaliacaoUsuario = $avaliacao->readMediaByAnuncioUserId($userId);

    function renderStars($mediaAvaliacao) {
        $fullStars = floor($mediaAvaliacao);
        $halfStar = $mediaAvaliacao - $fullStars >= 0.5 ? 1 : 0;
        $emptyStars = 5 - $fullStars - $halfStar;

        $starsHtml = str_repeat('<span class="star">&#9733;</span>', $fullStars);
        $starsHtml .= str_repeat('<span class="star">&#9734;</span>', $halfStar);
        $starsHtml .= str_repeat('<span class="star">&#9734;</span>', $emptyStars);

        return $starsHtml;
    }

    try {
        if (!$usuario->readById($userId)) {
            echo "<script>alert('Nenhum usuário encontrado.');window.location.href = 'index.php';</script>";
            exit();
        }
    } catch (PDOException $e) {
        echo "<script>alert('Erro ao buscar dados do usuário: " . $e->getMessage() . "');window.location.href = 'index.php';</script>";
        exit();
    }

    try {
        $ads = $ad->readAllByUserId($pdo, $userId);
    } catch (PDOException $e) {
        echo "<script>alert('Erro ao buscar anúncios do usuário: " . $e->getMessage() . "');window.location.href = 'index.php';</script>";
        exit();
    }
    ?>

    <nav class="nav">
        <a href="index.php"><img class="nav-logo" src="./assets/img/title.svg"></a>
        <ul class="nav-items">
            <li class="nav-item" id="nav-Nossos-servicos"><a href="home.php">Nossos serviços</a></li>
            <li class="nav-item" id="nav-Criar-anuncio"><a href="criaranuncio.php">Criar um anúncio</a></li>
            <li class="nav-item"><a href="perfil.php">Perfil</a></li>
        </ul>
    </nav>

    <div class="main">
        <div class="left">
            <h1 class="title"><?php echo htmlspecialchars($usuario->getLogin());?></h1>
            <div class="info-perfil" id="email-perfil"><b>Email:</b> <?php echo htmlspecialchars($usuario->getEmail()); ?></div>
            <div class="info-perfil" id="avaliacao-perfil"><span class="stars"><?php echo renderStars($mediaAvaliacaoUsuario); ?></span></div>
        </div>
        <div class="right">
            <h1 class="title">Anúncios:</h1>
            <?php if ($ads): ?>
                <div class="anuncios">
                    <?php foreach ($ads as $ad): ?>
                        <a href="anuncioprofissional.php?idAnuncio=<?= $ad['IDANUNCIO'] ?>" style="display: block;">
                            <div class="anuncio">
                                <div class="anuncio-img">
                                    <?php
                                    $imgPath = htmlspecialchars($ad['IMAGEMCAPA']);
                                    if (file_exists($imgPath)) {
                                        echo "<img src='$imgPath' alt='Imagem do anúncio'>";
                                    } else {
                                        echo "<img src='./assets/img/default.png' alt='Imagem padrão'>";
                                    }
                                    ?>
                                </div>
                                <div class="titulo-anuncio">
                                    <h1><?= htmlspecialchars($ad['NOME']) ?></h1>
                                    <h2><?= htmlspecialchars($ad['TRABALHO']) ?></h2>
                                </div>
                                <div class="descricao"><?= htmlspecialchars($ad['DESCRICAO']) ?></div>
                            </div>
                        </a>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <p>Nenhum anúncio encontrado.</p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
