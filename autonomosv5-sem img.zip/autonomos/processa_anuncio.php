<?php
require 'classeanuncio.php';
require 'conexao.php';
require 'classeusuario.php';

// Verifica se a sessão já está ativa antes de iniciar uma nova sessão
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

try {
    $idUsuario = Usuario::verificarAutenticacao();
    if (!$idUsuario) {
        echo "Usuário não autenticado.";
        exit;
    }

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $anuncio = new Anuncio();
        $anuncio->setIdUsuario($idUsuario);
        $anuncio->setNome($_POST['nome']);
        $anuncio->setRedeSocial($_POST['redesocial']);
        $anuncio->setTelefone($_POST['telefone']);
        $anuncio->setEmail($_POST['email'] ?? '');
        $anuncio->setTrabalho($_POST['trabalho']);
        $anuncio->setEspecializacao($_POST['especializacao']);
        $anuncio->setLocal($_POST['local']);
        $anuncio->setDescricao($_POST['descricao']);
        $anuncio->setDescricaoSimples($_POST['descricaoSimples']);
        $anuncio->setHorarios($_POST['horarios']);

        $targetDir = "uploads/";
        $imagemCapa = "";
        $imagensAdicionais = [];

        // Processar a imagem de capa (opcional)
        if (isset($_FILES["imagemCapa"]) && $_FILES["imagemCapa"]["error"] == 0) {
            $targetFileCapa = $targetDir . uniqid() . '_' . basename($_FILES["imagemCapa"]["name"]);
            if (move_uploaded_file($_FILES["imagemCapa"]["tmp_name"], $targetFileCapa)) {
                $imagemCapa = $targetFileCapa;
            } else {
                echo "Desculpe, houve um erro ao enviar a imagem de capa.";
                exit;
            }
        }

        // Processar imagens adicionais (opcional)
        if (!empty($_FILES["imagensAdicionais"])) {
            foreach ($_FILES["imagensAdicionais"]["tmp_name"] as $key => $tmp_name) {
                if ($_FILES["imagensAdicionais"]["error"][$key] == 0) {
                    $targetFile = $targetDir . uniqid() . '_' . basename($_FILES["imagensAdicionais"]["name"][$key]);
                    if (move_uploaded_file($_FILES["imagensAdicionais"]["tmp_name"][$key], $targetFile)) {
                        $imagensAdicionais[] = $targetFile;
                    } else {
                        echo "Desculpe, houve um erro ao enviar uma das imagens adicionais.";
                        exit;
                    }
                }
            }
        }

        $anuncio->setImagemCapa($imagemCapa);
        $anuncio->setImagensAdicionais(!empty($imagensAdicionais) ? implode(',', $imagensAdicionais) : '');

        if ($anuncio->create($conexao)) {
            echo "<script>alert('Anúncio criado com sucesso!');window.location.href = 'home.php';</script>";
        } else {
            echo "Falha ao criar o anúncio.";
        }
    } else {
        echo "Método de requisição inválido.";
    }
} catch (PDOException $e) {
    echo "Erro de conexão: " . $e->getMessage();
}
?>
