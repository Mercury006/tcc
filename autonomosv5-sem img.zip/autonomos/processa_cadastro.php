<?php
// Verifica se os dados foram enviados via POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtém os dados do formulário
    $login = isset($_POST["login"]) ? $_POST["login"] : null;
    $senha = isset($_POST["senha"]) ? $_POST["senha"] : null;
    $email = isset($_POST["email"]) ? $_POST["email"] : null;
    $cpf = isset($_POST["cpf"]) ? $_POST["cpf"] : null;

    // Inclui o arquivo da classe Usuario
    require "classeusuario.php";

    // Cria uma instância da classe Usuario passando a conexão PDO como argumento
    $pdo = new PDO('mysql:host=localhost;dbname=autonomos', 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $usuario = new Usuario($pdo);

    // Define os valores dos atributos da classe Usuario
    $usuario->setLogin($login);
    $usuario->setSenha($senha);
    $usuario->setEmail($email);
    $usuario->setCpf($cpf);

    // Tenta criar o usuário
    try {
        if ($usuario->create()) { // Chama o método create da classe Usuario
            // Mensagem de sucesso
            echo "<script>alert('Usuário cadastrado com sucesso!');window.location.href = 'login.php';</script>";
        } else {
            // Se ocorrer um erro ao inserir
            // Mensagem de erro
            echo "<script>alert('Erro ao cadastrar o usuário.');window.location.href = 'cadastro.php';</script>";
        }
    } catch (PDOException $e) {
        // Se ocorrer um erro durante a execução do método create
        // Mensagem de erro
        echo "<script>alert('Erro ao cadastrar o usuário: ".$e->getMessage()."');window.location.href = 'cadastro.php';</script>";
    }
}
?>
