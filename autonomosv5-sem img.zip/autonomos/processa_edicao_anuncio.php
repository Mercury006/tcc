<?php
session_start();

if (!isset($_SESSION['idUsuario'])) {
    echo "<script>alert('Você precisa estar logado para acessar esta página.');window.location.href = 'login.php';</script>";
    exit();
}

require('classeanuncio.php');
require('conexao.php');

$anuncio = new Anuncio();

if (!isset($_POST['idAnuncio'])) {
    echo "<script>alert('ID de anúncio não fornecido.');window.location.href = 'perfil.php';</script>";
    exit();
}

$anuncio->setIdAnuncio($_POST['idAnuncio']);
$anuncio->setIdUsuario($_SESSION['idUsuario']);
$anuncio->setNome($_POST['nome']);
$anuncio->setTrabalho($_POST['trabalho']);
$anuncio->setEspecializacao($_POST['especializacao']);
$anuncio->setTelefone($_POST['telefone']);
$anuncio->setDescricao($_POST['descricao']);
$anuncio->setDescricaoSimples($_POST['descricaoSimples']);
$anuncio->setHorarios($_POST['horarios']);
$anuncio->setRedeSocial($_POST['redesocial']);
$anuncio->setLocal($_POST['local']);

if (isset($_FILES['imagemCapa']) && $_FILES['imagemCapa']['error'] === UPLOAD_ERR_OK) {
    $extensao = strtolower(pathinfo($_FILES['imagemCapa']['name'], PATHINFO_EXTENSION));
    $novoNome = md5(time()) . "." . $extensao;
    $diretorio = "uploads/";
    move_uploaded_file($_FILES['imagemCapa']['tmp_name'], $diretorio . $novoNome);
    $anuncio->setImagemCapa($diretorio . $novoNome);
} else {
    $anuncio->setImagemCapa($_POST['imagem_atual']);
}

// Preserva imagens adicionais existentes
$imagensAdicionaisAtuais = explode(',', $_POST['imagens_adicionais_atuais']);
$imagensAdicionais = $imagensAdicionaisAtuais;

if (!empty($_FILES['imagensAdicionais']['name'][0])) {
    foreach ($_FILES['imagensAdicionais']['tmp_name'] as $key => $tmp_name) {
        if ($_FILES['imagensAdicionais']['error'][$key] === UPLOAD_ERR_OK) {
            $extensao = strtolower(pathinfo($_FILES['imagensAdicionais']['name'][$key], PATHINFO_EXTENSION));
            $novoNome = md5(time() + $key) . "." . $extensao;
            $diretorio = "uploads/";
            move_uploaded_file($tmp_name, $diretorio . $novoNome);
            $imagensAdicionais[] = $diretorio . $novoNome;
        }
    }
}

$anuncio->setImagensAdicionais(implode(',', $imagensAdicionais));

if ($anuncio->update($conexao)) {
    echo "<script>alert('Anúncio atualizado com sucesso!');window.location.href = 'perfil.php';</script>";
} else {
    echo "<script>alert('Erro ao atualizar o anúncio.');window.location.href = 'perfil.php';</script>";
}
?>
