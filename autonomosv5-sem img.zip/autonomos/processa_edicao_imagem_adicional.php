<?php
session_start();

if (!isset($_SESSION['idUsuario'])) {
    echo "<script>alert('Você precisa estar logado para acessar esta página.');window.location.href = 'login.php';</script>";
    exit();
}

require('classeanuncio.php');
require('conexao.php');

$anuncio = new Anuncio();

if (!isset($_POST['idAnuncio']) || !isset($_POST['imagemAtual'])) {
    echo "<script>alert('ID de anúncio ou imagem não fornecidos.');window.location.href = 'perfil.php';</script>";
    exit();
}

$idAnuncio = $_POST['idAnuncio'];
$imagemAtual = $_POST['imagemAtual'];

if (isset($_FILES['novaImagem']) && $_FILES['novaImagem']['error'] === UPLOAD_ERR_OK) {
    $extensao = strtolower(pathinfo($_FILES['novaImagem']['name'], PATHINFO_EXTENSION));
    $novoNome = md5(time()) . "." . $extensao;
    $diretorio = "uploads/";

    if (move_uploaded_file($_FILES['novaImagem']['tmp_name'], $diretorio . $novoNome)) {
        $novaImagem = $diretorio . $novoNome;

        if ($anuncio->read($conexao, $idAnuncio)) {
            $imagensAdicionais = $anuncio->getImagensAdicionais();
            $imagensArray = explode(',', $imagensAdicionais);

            foreach ($imagensArray as &$imagem) {
                if ($imagem === $imagemAtual) {
                    $imagem = $novaImagem;
                    break;
                }
            }

            $anuncio->setImagensAdicionais(implode(',', $imagensArray));

            if ($anuncio->update($conexao)) {
                echo "<script>alert('Imagem adicional atualizada com sucesso!');window.location.href = 'editaranuncio.php?idAnuncio=" . urlencode($idAnuncio) . "';</script>";
            } else {
                echo "<script>alert('Erro ao atualizar a imagem adicional.');window.location.href = 'editaranuncio.php?idAnuncio=" . urlencode($idAnuncio) . "';</script>";
            }
        } else {
            echo "<script>alert('Anúncio não encontrado.');window.location.href = 'perfil.php';</script>";
        }
    } else {
        echo "<script>alert('Erro ao fazer upload da nova imagem.');window.location.href = 'perfil.php';</script>";
    }
} else {
    echo "<script>alert('Nenhuma nova imagem foi selecionada.');window.location.href = 'perfil.php';</script>";
}