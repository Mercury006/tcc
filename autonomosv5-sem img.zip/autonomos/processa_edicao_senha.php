<?php
session_start();

if (!isset($_SESSION['idUsuario'])) {
    echo "<script>alert('Você precisa estar logado para acessar esta página.');window.location.href = 'login.php';</script>";
    exit();
}

require('classeusuario.php');
require('conexao.php');

$usuario = new Usuario($conexao);

// Verificar se todos os campos foram preenchidos
if (isset($_POST['senha_atual'], $_POST['senha'], $_POST['confirmar_senha'])) {
    $userId = $_SESSION['idUsuario'];
    $senha_atual = $_POST['senha_atual'];
    $nova_senha = $_POST['senha'];
    $confirmar_senha = $_POST['confirmar_senha'];

    // Ler o usuário pelo ID para verificar a senha atual
    if ($usuario->readById($userId)) {
        // Obtém a senha atual do objeto Usuario
        $senha_atual_bd = $usuario->getSenha();

        // Verificar se a senha atual digitada corresponde à senha no banco de dados
        if ($senha_atual === $senha_atual_bd) {
            // Verificar se as novas senhas coincidem
            if ($nova_senha === $confirmar_senha) {
                // Atualizar a senha
                if ($usuario->updateSenha($nova_senha)) {
                    echo "<script>alert('Senha atualizada com sucesso!');window.location.href = 'perfil.php';</script>";
                    exit();
                } else {
                    echo "<script>alert('Erro ao atualizar a senha.');window.location.href = 'alterarsenhausuario.php';</script>";
                    exit();
                }
            } else {
                echo "<script>alert('As senhas novas não coincidem.');window.location.href = 'alterarsenhausuario.php';</script>";
                exit();
            }
        } else {
            echo "<script>alert('Senha atual incorreta.');window.location.href = 'alterarsenhausuario.php';</script>";
            exit();
        }
    } else {
        echo "<script>alert('Usuário não encontrado.');window.location.href = 'perfil.php';</script>";
        exit();
    }
} else {
    echo "<script>alert('Por favor, preencha todos os campos.');window.location.href = 'alterarsenhausuario.php';</script>";
    exit();
}
?>
