<?php
session_start();
if (!isset($_SESSION['idUsuario'])) {
    echo "<script>alert('Você precisa estar logado para acessar esta página.');window.location.href = 'login.php';</script>";
    exit();
}

require('classeusuario.php');
require('conexao.php');

$usuario = new Usuario($conexao);
$usuario->setIdUsuario($_SESSION['idUsuario']);
$usuario->setEmail($_POST['email']);
$usuario->setCpf($_POST['cpf']);
$usuario->setLogin($_POST['login']);
$usuario->setSenha($_POST['senha']);


if ($usuario->update()) {
    echo "<script>alert('Informações atualizadas com sucesso!');window.location.href = 'perfil.php';</script>";
} else {
    echo "<script>alert('Erro ao atualizar informações.');window.location.href = 'editar_usuario.php';</script>";
}
?>
