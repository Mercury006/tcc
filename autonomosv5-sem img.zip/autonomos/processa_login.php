<?php
// Verifica se os dados foram enviados via POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtém os dados do formulário
    $login = isset($_POST["login"]) ? $_POST["login"] : null;
    $senha = isset($_POST["senha"]) ? $_POST["senha"] : null;

    // Verifica se os campos de login e senha foram preenchidos
    if (is_null($login) || is_null($senha)) {
        echo "<script>alert('Por favor, preencha todos os campos.');window.location.href = 'login.php';</script>";
        exit();
    }

    // Inclui o arquivo da classe Usuario
    require "classeusuario.php";

    // Cria uma instância da classe Usuario passando a conexão PDO como argumento
    try {
        $pdo = new PDO('mysql:host=localhost;dbname=autonomos', 'root', '');
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch (PDOException $e) {
        echo "<script>alert('Erro ao conectar ao banco de dados: " . $e->getMessage() . "');window.location.href = 'login.php';</script>";
        exit();
    }

    $usuario = new Usuario($pdo);

    // Tenta realizar o login
    try {
        // Verifica se o usuário existe no banco de dados e a senha está correta
        if ($usuario->read($login, $senha)) {
            // Login bem-sucedido
            session_start();
            $_SESSION["usuario"] = $usuario->getLogin();
            $_SESSION["idUsuario"] = $usuario->getIdUsuario();
            
            header("Location: home.php"); // Redireciona para a página restrita
            exit();
        } else {
            // Login ou senha incorretos
            echo "<script>alert('Login ou senha incorretos.');window.location.href = 'login.php';</script>";
        }
    } catch (PDOException $e) {
        // Em caso de erro na execução da instrução SQL, lança uma exceção
        echo "<script>alert('Erro ao realizar o login: " . $e->getMessage() . "');window.location.href = 'login.php';</script>";
    }
} else {
    // Redireciona para a página de login caso não tenha sido enviado via POST
    header("Location: login.php");
    exit();
}

