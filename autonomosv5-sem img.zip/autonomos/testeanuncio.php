<?php
require('classeanuncio.php');
require('conexao.php');

// Instancia um novo objeto Anuncio
$anuncio = new Anuncio();
$anuncio->setIdAnuncio(55); // Define o ID do anúncio a ser atualizado
$anuncio->setIdUsuario(1);
$anuncio->setNome('Nome Teste');
$anuncio->setTrabalho('Trabalho Teste');
$anuncio->setEspecializacao('Especializacao Teste');
$anuncio->setTelefone('123456789');
$anuncio->setDescricao('Descricao Teste');
$anuncio->setHorarios('Horarios Teste');
$anuncio->setRedeSocial('Rede Social Teste');
$anuncio->setLocal('Local Teste');
$anuncio->setImagemCapa('uploads/imagem_teste.jpg');
$anuncio->setImagensAdicionais('uploads/imagem1.jpg,uploads/imagem2.jpg');

// Tenta atualizar o anúncio no banco de dados
if ($anuncio->update($conexao)) {
    echo "Anúncio atualizado com sucesso!";
} else {
    echo "Erro ao atualizar o anúncio.";
}
?>